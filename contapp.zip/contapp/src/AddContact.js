import React, { Component } from "react";
import { Consumer } from "./Context";
import uuid from "uuid";

class AddContact extends Component {
  state = {
    name: "",
    email: "",
    phone: ""
  };
  onChangeHandler = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmitHandler = (dispatch, e) => {
    e.preventDefault();
    const { name, email, phone } = this.state;
    const newContact = {
      id: uuid(),
      name,
      email,
      phone
    };
    dispatch({
      type: "ADD_CONTACT_SAMIR_ARJUN_DEEPAN",
      payload: newContact
    });
    this.setState({
      name: "",
      email: "",
      phone: ""
    });
  };
  render() {
    return (
      <Consumer>
        {value => {
          const { contacts, dispatch } = value;
          return (
            <form onSubmit={this.onSubmitHandler.bind(this, dispatch)}>
              <div class="form-group">
                <label for="exampleInputEmail1">Name</label>
                <input
                  type="text"
                  class="form-control"
                  id="name"
                  name="name"
                  aria-describedby="emailHelp"
                  placeholder="Enter name"
                  value={this.state.name}
                  onChange={this.onChangeHandler.bind(this)}
                />
              </div>
              <div class="form-group">
                <label for="email">email</label>
                <input
                  type="email"
                  class="form-control"
                  id="email"
                  name="email"
                  aria-describedby="emailHelp"
                  placeholder="Enter email"
                  value={this.state.email}
                  onChange={this.onChangeHandler.bind(this)}
                />
              </div>
              <div class="form-group">
                <label for="phone">phone</label>
                <input
                  type="text"
                  class="form-control"
                  id="phone"
                  name="phone"
                  aria-describedby="emailHelp"
                  placeholder="Enter phone"
                  value={this.state.phone}
                  onChange={this.onChangeHandler.bind(this)}
                />
              </div>

              <button type="submit" class="btn btn-primary">
                Submit
              </button>
            </form>
          );
        }}
      </Consumer>
    );
  }
}

export default AddContact;
