import React, { Component } from "react";
import { Consumer } from "./Context";

class Header extends Component {
  render() {
    return (
      <Consumer>
        {value => {
          const { contacts } = value;
          return contacts.map(contact => {
            return (
              <div>
                <p>{contact.id}</p>
                <p>{contact.name}</p>
                <p>{contact.email}</p>
                <p>{contact.phone}</p>
              </div>
            );
          });
        }}
      </Consumer>
    );
  }
}

export default Header;
