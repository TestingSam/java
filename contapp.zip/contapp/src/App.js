import React from "react";
import { Provider } from "./Context";
import Header from "./Header";
import AddContact from "./AddContact";
import ApiTest from "./ApiTest";
function App() {
  return (
    <Provider>
      <div className="App">
        <Header />
        <AddContact />
        <ApiTest />
      </div>
    </Provider>
  );
}

export default App;
