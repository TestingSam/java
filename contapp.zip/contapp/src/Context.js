import React, { Component } from "react";

const Context = React.createContext();

const reducer = (state, action) => {
  switch (action.type) {
    case "ADD_CONTACT_SAMIR_ARJUN_DEEPAN":
      return {
        ...state,
        contacts: [action.payload, ...state.contacts]
      };
    default:
      return { state };
  }
};

export class Provider extends Component {
  state = {
    contacts: [
      {
        id: 1,
        name: "Samir1",
        email: "Samir1@samir.com",
        phone: "720000337"
      },
      {
        id: 2,
        name: "Samir1",
        email: "Samir1@samir.com",
        phone: "720000337"
      }
    ],
    dispatch: action => {
      this.setState(state => reducer(state, action));
    }
  };
  render() {
    return (
      <Context.Provider value={this.state}>
        {this.props.children}
      </Context.Provider>
    );
  }
}

export const Consumer = Context.Consumer;
