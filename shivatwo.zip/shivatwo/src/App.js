import React from "react";
import { Provider } from "./Context";
import Header from "./Header";

function App() {
  return (
    <Provider>
      <div className="App">
        <Header />
      </div>
    </Provider>
  );
}

export default App;
