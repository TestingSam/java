import React, { Component } from "react";
import { Consumer } from "./Context";

class Header extends Component {
  onClickHandler = dispatch => {
    dispatch({
      type: "CHANGE_HEADER",
      payload: "Samir Contact Management System"
    });
  };

  render() {
    return (
      <Consumer>
        {value => {
          const { header, dispatch } = value;
          return (
            <div>
              <h1>{header.name}</h1>
              <button
                className="btn btn-dander"
                onClick={this.onClickHandler.bind(this, dispatch)}
              >
                {" "}
                CHANGE{" "}
              </button>
            </div>
          );
        }}
      </Consumer>
    );
  }
}

export default Header;
