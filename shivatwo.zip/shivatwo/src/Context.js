import React, { Component } from "react";

const Context = React.createContext();
const reducer = (state, action) => {
  switch (action.type) {
    case "DELETE_FUNCTIONALITY":
      return {
        ...state,
        contacts: this.state.contacts.filter(
          contact => contact.id != action.payload
        )
      };
    case "CHANGE_HEADER":
      return {
        ...state,
        header: {
          name: action.payload
        }
      };
    default:
      return { state };
  }
};

export class Provider extends Component {
  state = {
    contacts: [
      {
        id: 1,
        name: "samir1",
        email: "samiralurhp@gmail.com",
        phone: "7200003327"
      },
      {
        id: 2,
        name: "samir2",
        email: "samir2@gmail.com",
        phone: "1234567890"
      },
      {
        id: 3,
        name: "samir3",
        email: "samir3@gmail.com",
        phone: "1234567890"
      }
    ],
    header: {
      name: "Contact Management System"
    },
    dispatch: action => {
      this.setState(state => reducer(state, action));
    }
  };
  render() {
    return (
      <Context.Provider value={this.state}>
        {this.props.children}
      </Context.Provider>
    );
  }
}

export const Consumer = Context.Consumer;
