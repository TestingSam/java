const express = require("express");
var bodyParser = require("body-parser");
const app = express();
const cors = require("cors");
var yahooFinance = require("yahoo-finance");
var mydate = require("current-date");
var csvWriter = require("csv-write-stream");
const fs = require("fs");
const exec = require("child_process").exec;
var readTextFile = require("read-text-file");
const jsonfile = require("jsonfile");
var csvsync = require("csvsync");
var pythonCmd2 = 'python "Sentiment Analysispy"';
var pythonCmd3 = 'python "Sentiment Analysis2.py"';
var pythonCmd = 'python "Stock price prediction.py"';
var pythonCmd4 = 'python "Stock price predictionStyles.py"';
var Excel = require("exceljs");
var workbook = new Excel.Workbook();
const port = process.env.PORT || 5000;
var multer = require("multer");
var lineReader = require("line-reader");
var LineByLineReader = require("line-by-line");
const tesseract = require("node-tesseract-ocr");
var Jimp = require("jimp");
const config = {
  lang: "eng",
  oem: 1,
  psm: 3
};
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static("public"));

function execShellCommand(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        console.warn(error);
      }
      resolve(stdout ? stdout : stderr);
    });
  });
}
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function replaceAll(str, term, replacement) {
  return str.replace(new RegExp(escapeRegExp(term), "g"), replacement);
}
// console.log that your server is up and running
app.listen(port, () => console.log(`Listening on port ${port}`));
var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, "public");
  },
  filename: function(req, file, cb) {
    //cb(null, Date.now() + "-" + file.originalname);
    cb(null, file.originalname);
  }
});

var upload = multer({ storage: storage }).single("file");
var uploadLot = multer({ storage: storage }).array("file");

// create a GET route
app.get("/express_backend", (req, res) => {
  res.send({ express: "YOUR EXPRESS BACKEND IS CONNECTED TO REACT" });
});

app.post("/uploadMutiple", function(req, res) {
  try {
    fs.unlinkSync(__dirname + "//public//PDFContent.txt");
    fs.unlinkSync(__dirname + "//public//DOCContent.txt");
    fs.unlinkSync(__dirname + "//public//ImageContent.txt");
    //file removed
  } catch (err) {}
  var finalProcessedFiles = uploadLot(req, res, function(err) {
    var processedFileName = [];
    if (err instanceof multer.MulterError) {
      return res.status(500).json(err);
    } else if (err) {
      return res.status(500).json(err);
    }
    req.files.map(file => {
      console.log(file.originalname);
      console.log(file.path);
      var OutPutfileName = file.originalname;
      if (OutPutfileName.includes(".pdf")) {
        console.log("You have uploaded a PDF file");
        OutPutfileName = OutPutfileName.replace(".pdf", "");
        OutPutfileName = OutPutfileName + "Out" + ".pdf";
        exec("java -jar .//public//ReadPDF.jar " + file.path + "", function(
          error,
          stdout,
          stderr
        ) {
          var PIIDATA = [];
          var PIIDATAString;
          var lines = [];
          lr = new LineByLineReader(__dirname + "//public//PDFContent.txt");
          lr.on("line", function(line) {
            lines.push(line);
          });
          lr.on("end", async function() {
            //console.log(lines);
            for (var j = 0; j < lines.length; j++) {
              const execInfo = await execShellCommand(
                'python public\\NLP_Code.py "' + lines[j] + '"'
              );
              var piidataInfoIntermediat = execInfo
                .split("\r\n")
                .join()
                .substring(0, execInfo.split("\r\n").join().length - 1);
              piidataInfoIntermediat = replaceAll(
                piidataInfoIntermediat,
                " ",
                ","
              );
              console.log(piidataInfoIntermediat);
              if (execInfo.length != 0) {
                PIIDATA.push(piidataInfoIntermediat);
              }
            }
            console.log("PIIDATA");
            console.log(PIIDATA);
            PIIDATAString = PIIDATA.join();
            PIIDATAString = PIIDATAString.replace(
              /(?:\\[rn]|[\r\n]+)+/g,
              ""
            ).replace(",,", ",");
            const execInfo = await execShellCommand(
              'java -jar public\\highPDF.jar "' +
                file.path +
                '" "' +
                PIIDATAString +
                '" "' +
                file.destination +
                "//" +
                OutPutfileName +
                '"'
            );
            //return res.send(OutPutfileName);
            processedFileName.push(OutPutfileName);
          });
          //return res.status(200).send(req.file);
        });
      } else if (
        OutPutfileName.includes(".docx") ||
        OutPutfileName.includes(".doc")
      ) {
        console.log("you have uploaded a Document");
        OutPutfileName = OutPutfileName.replace(".docx", "");
        OutPutfileName = OutPutfileName + "Out" + ".docx";
        exec("java -jar .//public//ReadWORD.jar " + file.path + "", function(
          error,
          stdout,
          stderr
        ) {
          var PIIDATA = [];
          var PIIDATAString;
          var lines = [];
          lr = new LineByLineReader(__dirname + "//public//DOCContent.txt");
          lr.on("line", function(line) {
            lines.push(line);
          });
          lr.on("end", async function() {
            //console.log(lines);
            for (var j = 0; j < lines.length; j++) {
              const execInfo = await execShellCommand(
                'python public\\NLP_Code.py "' + lines[j] + '"'
              );
              var piidataInfoIntermediat = execInfo
                .split("\r\n")
                .join()
                .substring(0, execInfo.split("\r\n").join().length - 1);
              piidataInfoIntermediat = replaceAll(
                piidataInfoIntermediat,
                " ",
                ","
              );
              console.log(piidataInfoIntermediat);
              if (execInfo.length != 0) {
                PIIDATA.push(piidataInfoIntermediat);
              }
            }
            console.log("PIIDATA");
            console.log(PIIDATA);
            PIIDATAString = PIIDATA.join();
            PIIDATAString = PIIDATAString.replace(
              /(?:\\[rn]|[\r\n]+)+/g,
              ""
            ).replace(",,", ",");
            const execInfo = await execShellCommand(
              'java -jar public\\highWord.jar "' +
                file.path +
                '" "' +
                PIIDATAString +
                '" "' +
                file.destination +
                "//" +
                OutPutfileName +
                '"'
            );
            //return res.send(OutPutfileName);
            processedFileName.push(OutPutfileName);
          });
        });
      } else if (
        OutPutfileName.includes(".xlsx") ||
        OutPutfileName.includes(".xls")
      ) {
        console.log("you have uploaded an excel file");
        OutPutfileName = OutPutfileName.replace(".xlsx", "");
        OutPutfileName = OutPutfileName + "Out" + ".xlsx";
        exec("java -jar .//public//ExcelRead.jar " + file.path + "", function(
          error,
          stdout,
          stderr
        ) {
          var PIIDATA = [];
          var PIIDATAString;
          var lines = [];
          lr = new LineByLineReader(__dirname + "//public//ExcelContent.txt");
          lr.on("line", function(line) {
            lines.push(line);
          });
          lr.on("end", async function() {
            //console.log(lines);
            for (var j = 0; j < lines.length; j++) {
              const execInfo = await execShellCommand(
                'python public\\NLP_Code.py "' + lines[j] + '"'
              );
              var piidataInfoIntermediat = execInfo
                .split("\r\n")
                .join()
                .substring(0, execInfo.split("\r\n").join().length - 1);
              piidataInfoIntermediat = replaceAll(
                piidataInfoIntermediat,
                " ",
                ","
              );
              console.log(piidataInfoIntermediat);
              if (execInfo.length != 0) {
                PIIDATA.push(piidataInfoIntermediat);
              }
            }
            console.log("PIIDATA");
            console.log(PIIDATA);
            PIIDATAString = PIIDATA.join();
            PIIDATAString = PIIDATAString.replace(
              /(?:\\[rn]|[\r\n]+)+/g,
              ""
            ).replace(",,", ",");
            const execInfo = await execShellCommand(
              'java -jar public\\ExcelHigh.jar "' +
                file.path +
                '" "' +
                PIIDATAString +
                '" "' +
                file.destination +
                "//" +
                OutPutfileName +
                '"'
            );
            //return res.send(OutPutfileName);
            processedFileName.push(OutPutfileName);
          });
        });
      } else if (
        OutPutfileName.includes(".JPG") ||
        OutPutfileName.includes(".png") ||
        OutPutfileName.includes(".jpg")
      ) {
        console.log("You have uploaded an image");
        OutPutfileName = OutPutfileName.replace(".JPG", "");
        OutPutfileName = OutPutfileName + "Out" + ".txt";
        tesseract
          .recognize(__dirname + "\\" + file.path + "", config)
          .then(text => {
            var stream = fs.createWriteStream(
              __dirname + "\\public\\" + "ImageContent.txt"
            );
            stream.once("open", function(fd) {
              for (var i = 0; i < text.split("\r\n").length; i++) {
                stream.write(text.split("\r\n")[i] + "\n");
              }
              stream.end();
            });
            var PIIDATA = [];
            var PIIDATAString;
            var lines = [];
            lr = new LineByLineReader(__dirname + "//public//ImageContent.txt");
            lr.on("line", function(line) {
              lines.push(line);
            });
            lr.on("end", async function() {
              //console.log(lines);
              for (var j = 0; j < lines.length; j++) {
                const execInfo = await execShellCommand(
                  'python public\\NLP_Code.py "' + lines[j] + '"'
                );
                var piidataInfoIntermediat = execInfo
                  .split("\r\n")
                  .join()
                  .substring(0, execInfo.split("\r\n").join().length - 1);
                piidataInfoIntermediat = replaceAll(
                  piidataInfoIntermediat,
                  " ",
                  ","
                );
                console.log(piidataInfoIntermediat);
                if (execInfo.length != 0) {
                  PIIDATA.push(piidataInfoIntermediat);
                }
              }
              console.log("PIIDATA");
              console.log(PIIDATA);
              PIIDATAString = PIIDATA.join();
              PIIDATAString = PIIDATAString.replace(
                /(?:\\[rn]|[\r\n]+)+/g,
                ""
              ).replace(",,", ",");
              var logger = fs.createWriteStream("public\\" + OutPutfileName, {
                flags: "a" // 'a' means appending (old data will be preserved)
              });
              logger.write(PIIDATAString);
              logger.end();
              return res.send(OutPutfileName);
            });
            //return res.status(200).send(req.file);
          })
          .catch(err => {
            console.log("error:", err);
          });
      }
    });
    //return res.status(200).send(req.files);
    return processedFileName;
  });
  //console.log(finalProcessedFiles);
});

app.post("/upload", function(req, res) {
  try {
    fs.unlinkSync(__dirname + "//public//PDFContent.txt");
    fs.unlinkSync(__dirname + "//public//DOCContent.txt");
    fs.unlinkSync(__dirname + "//public//ImageContent.txt");
    //file removed
  } catch (err) {}
  upload(req, res, function(err) {
    if (err instanceof multer.MulterError) {
      return res.status(500).json(err);
    } else if (err) {
      return res.status(500).json(err);
    }
    var OutPutfileName = req.file.originalname;
    if (OutPutfileName.includes(".pdf")) {
      console.log("You have uploaded a PDF file");
      OutPutfileName = OutPutfileName.replace(".pdf", "");
      OutPutfileName = OutPutfileName + "Out" + ".pdf";
      exec("java -jar .//public//ReadPDF.jar " + req.file.path + "", function(
        error,
        stdout,
        stderr
      ) {
        var PIIDATA = [];
        var PIIDATAString;
        var lines = [];
        lr = new LineByLineReader(__dirname + "//public//PDFContent.txt");
        lr.on("line", function(line) {
          lines.push(line);
        });
        lr.on("end", async function() {
          //console.log(lines);
          for (var j = 0; j < lines.length; j++) {
            const execInfo = await execShellCommand(
              'python public\\NLP_Code.py "' + lines[j] + '"'
            );
            var piidataInfoIntermediat = execInfo
              .split("\r\n")
              .join()
              .substring(0, execInfo.split("\r\n").join().length - 1);
            piidataInfoIntermediat = replaceAll(
              piidataInfoIntermediat,
              " ",
              ","
            );
            console.log(piidataInfoIntermediat);
            if (execInfo.length != 0) {
              PIIDATA.push(piidataInfoIntermediat);
            }
          }
          console.log("PIIDATA");
          console.log(PIIDATA);
          PIIDATAString = PIIDATA.join();
          PIIDATAString = PIIDATAString.replace(
            /(?:\\[rn]|[\r\n]+)+/g,
            ""
          ).replace(",,", ",");
          const execInfo = await execShellCommand(
            'java -jar public\\highPDF.jar "' +
              req.file.path +
              '" "' +
              PIIDATAString +
              '" "' +
              req.file.destination +
              "//" +
              OutPutfileName +
              '"'
          );
          var responseData = {};
          responseData.fileName = OutPutfileName;
          responseData.count = PIIDATAString.split(",").length;
          return res.send(responseData);
        });
        //return res.status(200).send(req.file);
      });
    } else if (
      OutPutfileName.includes(".docx") ||
      OutPutfileName.includes(".doc")
    ) {
      console.log("you have uploaded a Document");
      OutPutfileName = OutPutfileName.replace(".docx", "");
      OutPutfileName = OutPutfileName + "Out" + ".docx";
      exec("java -jar .//public//ReadWORD.jar " + req.file.path + "", function(
        error,
        stdout,
        stderr
      ) {
        var PIIDATA = [];
        var PIIDATAString;
        var lines = [];
        lr = new LineByLineReader(__dirname + "//public//DOCContent.txt");
        lr.on("line", function(line) {
          lines.push(line);
        });
        lr.on("end", async function() {
          //console.log(lines);
          for (var j = 0; j < lines.length; j++) {
            const execInfo = await execShellCommand(
              'python public\\NLP_Code.py "' + lines[j] + '"'
            );
            var piidataInfoIntermediat = execInfo
              .split("\r\n")
              .join()
              .substring(0, execInfo.split("\r\n").join().length - 1);
            piidataInfoIntermediat = replaceAll(
              piidataInfoIntermediat,
              " ",
              ","
            );
            console.log(piidataInfoIntermediat);
            if (execInfo.length != 0) {
              PIIDATA.push(piidataInfoIntermediat);
            }
          }
          console.log("PIIDATA");
          console.log(PIIDATA);
          PIIDATAString = PIIDATA.join();
          PIIDATAString = PIIDATAString.replace(
            /(?:\\[rn]|[\r\n]+)+/g,
            ""
          ).replace(",,", ",");
          const execInfo = await execShellCommand(
            'java -jar public\\highWord.jar "' +
              req.file.path +
              '" "' +
              PIIDATAString +
              '" "' +
              req.file.destination +
              "//" +
              OutPutfileName +
              '"'
          );
          var responseData = {};
          responseData.fileName = OutPutfileName;
          responseData.count = PIIDATAString.split(",").length;
          return res.send(responseData);
        });
        //return res.status(200).send(req.file);
      });
    } else if (
      OutPutfileName.includes(".xlsx") ||
      OutPutfileName.includes(".xls")
    ) {
      console.log("you have uploaded an excel file");
      OutPutfileName = OutPutfileName.replace(".xlsx", "");
      OutPutfileName = OutPutfileName + "Out" + ".xlsx";
      exec("java -jar .//public//ExcelRead.jar " + req.file.path + "", function(
        error,
        stdout,
        stderr
      ) {
        var PIIDATA = [];
        var PIIDATAString;
        var lines = [];
        lr = new LineByLineReader(__dirname + "//public//ExcelContent.txt");
        lr.on("line", function(line) {
          lines.push(line);
        });
        lr.on("end", async function() {
          //console.log(lines);
          for (var j = 0; j < lines.length; j++) {
            const execInfo = await execShellCommand(
              'python public\\NLP_Code.py "' + lines[j] + '"'
            );
            var piidataInfoIntermediat = execInfo
              .split("\r\n")
              .join()
              .substring(0, execInfo.split("\r\n").join().length - 1);
            piidataInfoIntermediat = replaceAll(
              piidataInfoIntermediat,
              " ",
              ","
            );
            console.log(piidataInfoIntermediat);
            if (execInfo.length != 0) {
              PIIDATA.push(piidataInfoIntermediat);
            }
          }
          console.log("PIIDATA");
          console.log(PIIDATA);
          PIIDATAString = PIIDATA.join();
          PIIDATAString = PIIDATAString.replace(
            /(?:\\[rn]|[\r\n]+)+/g,
            ""
          ).replace(",,", ",");
          const execInfo = await execShellCommand(
            'java -jar public\\ExcelHigh.jar "' +
              req.file.path +
              '" "' +
              PIIDATAString +
              '" "' +
              req.file.destination +
              "//" +
              OutPutfileName +
              '"'
          );
          var responseData = {};
          responseData.fileName = OutPutfileName;
          responseData.count = PIIDATAString.split(",").length;
          return res.send(responseData);
        });
        //return res.status(200).send(req.file);
      });
    } else if (
      OutPutfileName.includes(".JPG") ||
      OutPutfileName.includes(".png") ||
      OutPutfileName.includes(".jpg")
    ) {
      console.log("You have uploaded an image");
      OutPutfileName = OutPutfileName.replace(".JPG", "");
      OutPutfileName = OutPutfileName + "Out" + ".txt";
      tesseract
        .recognize(__dirname + "\\" + req.file.path + "", config)
        .then(text => {
          var stream = fs.createWriteStream(
            __dirname + "\\public\\" + "ImageContent.txt"
          );
          stream.once("open", function(fd) {
            for (var i = 0; i < text.split("\r\n").length; i++) {
              stream.write(text.split("\r\n")[i] + "\n");
            }
            stream.end();
          });
          var PIIDATA = [];
          var PIIDATAString;
          var lines = [];
          lr = new LineByLineReader(__dirname + "//public//ImageContent.txt");
          lr.on("line", function(line) {
            lines.push(line);
          });
          lr.on("end", async function() {
            //console.log(lines);
            for (var j = 0; j < lines.length; j++) {
              const execInfo = await execShellCommand(
                'python public\\NLP_Code.py "' + lines[j] + '"'
              );
              var piidataInfoIntermediat = execInfo
                .split("\r\n")
                .join()
                .substring(0, execInfo.split("\r\n").join().length - 1);
              piidataInfoIntermediat = replaceAll(
                piidataInfoIntermediat,
                " ",
                ","
              );
              console.log(piidataInfoIntermediat);
              if (execInfo.length != 0) {
                PIIDATA.push(piidataInfoIntermediat);
              }
            }
            console.log("PIIDATA");
            console.log(PIIDATA);
            PIIDATAString = PIIDATA.join();
            PIIDATAString = PIIDATAString.replace(
              /(?:\\[rn]|[\r\n]+)+/g,
              ""
            ).replace(",,", ",");
            var logger = fs.createWriteStream("public\\" + OutPutfileName, {
              flags: "a" // 'a' means appending (old data will be preserved)
            });
            logger.write(PIIDATAString);
            logger.end();
            var responseData = {};
            responseData.fileName = OutPutfileName;
            responseData.count = PIIDATAString.split(",").length;
            return res.send(responseData);
          });
          //return res.status(200).send(req.file);
        })
        .catch(err => {
          console.log("error:", err);
        });
    }
  });
});

app.post("/formModel", async function(req, res) {
  var tableRows = req.body.tableItems;
  var trainDataSet = "";
  var EntityName;
  var modelName;
  var trainData;
  var range;
  console.log(tableRows);
  /*tableRows.map(row => {
    trainData = row.username;
    range = row.password;
    EntityName = row.entityName;
    modelName = row.modelName;
    /*myData =
      '("' +
      trainData +
      '",{entities: [(' +
      range +
      ', "' +
      EntityName +
      '")]})';
    trainDataSet = trainDataSet + "," + myData;
  });*/
  trainData = tableRows[0].username;
  range = tableRows[0].password;
  EntityName = tableRows[0].entityName;
  modelName = tableRows[0].modelName;
  console.log(trainData);
  console.log(range);
  console.log(EntityName);
  console.log(modelName);
  const execInfo = await execShellCommand(
    "python public\\ModelCreation_FOR_NLP.py " +
      EntityName +
      ' "' +
      trainData +
      '" ' +
      range +
      " " +
      modelName +
      ""
  );
});
