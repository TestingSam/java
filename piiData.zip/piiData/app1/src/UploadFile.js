import React, { Component } from "react";
import "./Upload.css";
import axios from "axios";
import ReactDOM from "react-dom";
import Modal from "react-responsive-modal";
import FileViewer from "react-file-viewer";
const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  }
};
class UploadFile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      selectedFile: null,
      finalFile: null,
      modalIsOpen: false,
      numPages: null,
      pageNumber: 1,
      filetype: null,
      dataCount: null,
      showTable: false,
      fileNameOutPut: null
    };
  }
  onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages });
  };

  onOpenModal = () => {
    this.setState({ open: true });
  };

  onCloseModal = () => {
    this.setState({ open: false });
  };

  onChangeHandler = event => {
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0,
      showTable: false
    });
  };

  onClickHandler = () => {
    const data = new FormData();
    data.append("file", this.state.selectedFile);
    axios
      .post("http://localhost:5000/upload", data, {
        // receive two    parameter endpoint url ,form data
      })
      .then(res => {
        // then print response status
        console.log(res.data);
        var fileName = res.data.fileName;
        var piiDataCount = res.data.count;
        var type;
        if (fileName.includes(".docx")) {
          type = "docx";
        } else if (fileName.includes(".pdf")) {
          type = "pdf";
        }
        this.setState({
          finalFile: "http://localhost:5000/" + res.data.fileName,
          filetype: type,
          dataCount: piiDataCount,
          showTable: true,
          fileNameOutPut: res.data.fileName
        });
      });
  };
  render() {
    const { fileNameOutPut, showTable, dataCount, finalFile } = this.state;
    return (
      <React.Fragment>
        <div class="container">
          <div class="row">
            <div class="col-md-3" />
            <div class="col-md-6">
              <form method="post" action="#" id="#">
                <div class="form-group files">
                  <label>Upload Your File </label>
                  <input
                    type="file"
                    class="form-control"
                    multiple=""
                    name="file"
                    onChange={this.onChangeHandler}
                  />
                </div>
              </form>
              <button
                type="button"
                class="btn btn-success btn-block"
                onClick={this.onClickHandler}
              >
                Upload
              </button>
            </div>
          </div>
        </div>
        {showTable ? (
          <div class="container">
            <div className="row">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">OUTPUT FILE NAME</th>
                    <th scope="col">PII DATA COUNT</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>{fileNameOutPut}</td>
                    <td>
                      <a href={finalFile} target="_blank">
                        {dataCount}
                      </a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
      </React.Fragment>
    );
  }
}

export default UploadFile;
