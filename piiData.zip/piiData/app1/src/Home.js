import React, { Component } from "react";
import ReactDom from "react-dom";
import { Link } from "react-router-dom";

class Home extends Component {
  render() {
    return (
      <React.Fragment>
        <div class="jumbotron jumbotron-fluid bg-info">
          <div class="container">
            <h1 class="display-4">PII DATA IDENTIFIER</h1>
          </div>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <div class="card">
                <img
                  src="http://localhost:5000/code.jpg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <h5 class="card-title">Single Upload</h5>
                  <p class="card-text">
                    Upload single docx and png format files here
                  </p>
                  <Link to="/singleupload" href="#" class="btn btn-primary">
                    Click Here!
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div class="card">
                <img
                  src="http://localhost:5000/code.jpg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <h5 class="card-title">Multiple Upload</h5>
                  <p class="card-text">
                    Upload Multiple docx and png format files here
                  </p>
                  <Link to="/mutipleupload" href="#" class="btn btn-primary">
                    Click Here!
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div class="card">
                <img
                  src="http://localhost:5000/code.jpg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <h5 class="card-title">Create Custom PII identifier Model</h5>
                  <p class="card-text">
                    Feel free to create any model for custom PII
                  </p>
                  <Link to="/createModel" href="#" class="btn btn-primary">
                    Click Here!
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div class="card">
                <img
                  src="http://localhost:5000/code.jpg"
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  <h5 class="card-title">CO-ORDINATES EXTRACTOR</h5>
                  <p class="card-text">
                    Feel free to extract co-ordinates from images, pdf
                  </p>
                  <Link
                    to="/CoodinatesExtractor"
                    href="#"
                    class="btn btn-primary"
                  >
                    Click Here!
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default Home;
