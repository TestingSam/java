import React from "react";
import "./App.css";
import UploadFile from "./UploadFile";
import UploadMutiple from "./UploadMutiple";
import CoodinatesExtractor from "./CoodinatesExtractor";
import Home from "./Home";
import { Provider } from "react-redux";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import store from "./store";
import "bootstrap/dist/css/bootstrap.min.css";
import AppTable from "./AppTable";

function App() {
  return (
    <Provider store={store}>
      <Router>
        <div className="App">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/singleupload" component={UploadFile} />
            <Route exact path="/mutipleupload" component={UploadMutiple} />
            <Route exact path="/createModel" component={AppTable} />
            <Route
              exact
              path="/CoodinatesExtractor"
              component={CoodinatesExtractor}
            />
          </Switch>
        </div>
      </Router>
    </Provider>
  );
}

export default App;
