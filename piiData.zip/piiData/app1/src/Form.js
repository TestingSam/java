import React, { Component } from "react";
class Form extends Component {
  state = {
    flag: false
  };
  render() {
    return (
      <div id="Form">
        <h3>Train the Model</h3>
        <form onSubmit={this.props.handleFormSubmit}>
          <label htmlFor="username">
            Training Data
            <input
              id="username"
              value={this.props.newUsername}
              type="text"
              name="username"
              onChange={this.props.handleInputChange}
            />
          </label>
          <label for="password">
            Range Considered
            <input
              id="password"
              value={this.props.newPassword}
              type="text"
              name="password"
              onChange={this.props.handleInputChange}
            />
          </label>
          <label for="newModelName">
            Model Name
            <input
              id="modelName"
              value={this.props.newModelName}
              type="text"
              name="modelName"
              onChange={this.props.handleInputChange}
            />
          </label>
          <label for="newEntityName">
            Entity Name
            <input
              id="entityName"
              value={this.props.newEntityName}
              type="text"
              name="entityName"
              onChange={this.props.handleInputChange}
            />
          </label>
          <button class="btn btn-lg btn-success" type="submit" value="Submit">
            Add Data
          </button>
        </form>
      </div>
    );
  }
}

export default Form;
