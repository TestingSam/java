import React, { Component } from "react";
import axios from "axios";
class Table extends Component {
  onClickHandler = tableItems => {
    console.log(tableItems);
    axios.post(`http://localhost:5000/formModel`, { tableItems }).then(res => {
      console.log(res);
      console.log(res.data);
    });
  };
  render() {
    const items = this.props.items;
    return (
      <div id="Table">
        <table>
          <tbody>
            <tr>
              <th>Sample Train Data</th>
              <th>Range To Be Considered</th>
              <th>Model Name</th>
              <th>Entity Name</th>
            </tr>
            {items.map(item => {
              return (
                <tr>
                  <td>{item.username}</td>
                  <td>{item.password}</td>
                  <td>{item.modelName}</td>
                  <td>{item.entityName}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <button
          className="btn btn-lg btn-success"
          onClick={this.onClickHandler.bind(this, items)}
        >
          Create Model
        </button>
      </div>
    );
  }
}
export default Table;
