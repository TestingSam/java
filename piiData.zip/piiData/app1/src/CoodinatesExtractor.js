import React, { Component } from "react";
import Iframe from "react-iframe";

class CoodinatesExtractor extends Component {
  render() {
    return (
      <div>
        <Iframe
          url="https://jsoma.github.io/kull/#/"
          width="1400px"
          height="1200px"
          id="myId"
          className="myClassname"
          display="initial"
          position="relative"
        />
      </div>
    );
  }
}

export default CoodinatesExtractor;
