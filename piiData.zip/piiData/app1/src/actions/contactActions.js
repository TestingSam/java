import { GET_CONTACTS } from "./types";

export const getContactsList = () => {
  return {
    type: GET_CONTACTS
  };
};
