import React, { Component } from "react";
import axios from "axios";

class UploadMutiple extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      selectedFile: null,
      finalFile: null,
      modalIsOpen: false,
      numPages: null,
      pageNumber: 1,
      filetype: null
    };
  }
  onChangeHandler = event => {
    this.setState({
      selectedFile: event.target.files
    });
  };
  onClickHandler = () => {
    const data = new FormData();
    for (var x = 0; x < this.state.selectedFile.length; x++) {
      data.append("file", this.state.selectedFile[x]);
    }

    axios
      .post("http://localhost:5000/uploadMutiple", data, {
        // receive two    parameter endpoint url ,form data
      })

      .then(res => {
        // then print response status
        console.log(res);
      });
  };
  render() {
    return (
      <React.Fragment>
        <div class="container">
          <div class="row">
            <div class="col-md-3" />
            <div class="col-md-6">
              <form method="post" action="#" id="#">
                <div class="form-group files">
                  <label>Upload Your File </label>
                  <input
                    type="file"
                    class="form-control"
                    multiple
                    name="file"
                    onChange={this.onChangeHandler}
                  />
                </div>
              </form>
              <button
                type="button"
                class="btn btn-success btn-block"
                onClick={this.onClickHandler}
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default UploadMutiple;
