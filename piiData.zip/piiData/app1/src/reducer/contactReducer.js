import { GET_CONTACTS } from "../actions/types";

const initialState = {
  contacts: [
    {
      id: 1,
      name: "samir1",
      email: "samir1@samir.com",
      phone: "111111"
    },
    {
      id: 2,
      name: "samir2",
      email: "samir2@samir.com",
      phone: "2222222"
    },
    {
      id: 3,
      name: "samir3",
      email: "samir3@samir.com",
      phone: "333333"
    }
  ]
};

export default function(state = initialState, action) {
  switch (action.type) {
    case GET_CONTACTS:
      return {
        ...state
      };
    default:
      return state;
  }
}
