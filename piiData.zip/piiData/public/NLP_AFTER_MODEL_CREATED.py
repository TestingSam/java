#!/usr/bin/env python
# coding: utf-8

# In[29]:

import sys
import spacy
nlpEn = spacy.load('en_core_web_sm')
nlp = spacy.load('D:\shinu\piiData\public')
nlpssn = spacy.load('D:\shinu\piiData\public\ssn')
nlpDL = spacy.load('D:\shinu\piiData\public\DL4')
arguments = sys.argv[1]
print(arguments)
test_text = arguments
doc = nlp(test_text)
docEn = nlpEn(test_text)
docSsn = nlpssn(test_text)
docDL = nlpDL(test_text)
print("Entities in '%s'" % test_text)
for ent in doc.ents:
    print(ent.label_, ent.text)
for ent in docEn.ents:
    print(ent.label_, ent.text)
for ent in docSsn.ents:
    print(ent.label_, ent.text)
for ent in docDL.ents:
    print(ent.label_, ent.text)

