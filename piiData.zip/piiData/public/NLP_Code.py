#!/usr/bin/env python
# coding: utf-8

# In[65]:

import sys
import spacy
import re 
ssnRegexWithHiphen = re.compile(r'^\d{3}-\d{2}-\d{4}$') 
ssnRegexWithOutHiphen=re.compile(r'^\d{9}$') 
dateRegex=re.compile(r'[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$|[0-9]{1,2}-[a-zA-Z]{3}-[0-9]{4}$|[a-zA-Z]{3}-[0-9]{1,2}-[0-9]{4}$|[0-9]{1,2}/[a-zA-Z]{3}/[0-9]{4}$|[a-zA-Z]{3}/[0-9]{1,2}/[0-9]{4}$|[0-9]{1,2}-[a-zA-Z]{3}-[0-9]{4}$|[a-zA-Z]{3}-[0-9]{1,2}-[0-9]{4}$|[0-9]{1,2}/[a-zA-Z]{3}/[0-9]{4}$|[a-zA-Z]{3}/[0-9]{1,2}/[0-9]{4}$|[0-9]{1,2}-[a-zA-Z]{4}-[0-9]{4}$|[a-zA-Z]{4}-[0-9]{1,2}-[0-9]{4}$|[0-9]{1,2}/[a-zA-Z]{4}/[0-9]{4}$|[a-zA-Z]{4}/[0-9]{1,2}/[0-9]{4}$|[0-9]{1,2}-[a-zA-Z]{4}-[0-9]{2}$|[a-zA-Z]{4}-[0-9]{1,2}-[0-9]{2}$|[0-9]{1,2}/[a-zA-Z]{4}/[0-9]{2}$|[a-zA-Z]{4}/[0-9]{1,2}/[0-9]{2}$|[0-9]{1,2}-[a-zA-Z]{3}-[0-9]{2}$|[a-zA-Z]{3}-[0-9]{1,2}-[0-9]{2}$|[0-9]{1,2}/[a-zA-Z]{3}/[0-9]{2}$|[a-zA-Z]{3}/[0-9]{1,2}/[0-9]{2}$|[0-3]?[0-9]-[0-3]?[0-9]-(?:[0-9]{2})?[0-9]{2}$|[a-zA-Z]{3} [0-9]{1,2}, [0-9]{2}$|[a-zA-Z]{3} [0-9]{1,2}, [0-9]{4}$|[a-zA-Z]{4} [0-9]{1,2}, [0-9]{2}$|[a-zA-Z]{4} [0-9]{1,2}, [0-9]{4}$')
phoneNumberRegex=re.compile(r'^(1\s?)-?((\([0-9]{3}\))|[0-9]{3})[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$') 
creditCardNumberRegex=re.compile(r'^(\d{4}[- ]){3}\d{4}|\d{16}$')

def num_there(s):
    return any(i.isdigit() for i in s)

nlp = spacy.load('en_core_web_sm')
#sample_text="Mary is a working in Fidelity investments with Phone number 7200003327 at New York, his ssn is 111-11-1111 and his mail is samiralurhp@gmail.com, his date of birth is 18-06-1988 his credit card number is 1111-1111-1111-1111, his passport number is A12347135 Mar 15, 2010"
#print(sys.argv[1])
sample_text=sys.argv[1]
dateFound = dateRegex.search(sample_text) 
try:
    print(dateFound.group())
except:
    pass
tokens = [word for word in sample_text.split()]
#print(tokens)
from nltk.corpus import stopwords
stop_words=set(stopwords.words('english'))
def remove_stopwords(words):
    filtered_words = []
    for word in words:
        if word not in stop_words:
            filtered_words.append(word)
            
    return filtered_words
        
myCorrectedData= (remove_stopwords(tokens))
seperator = ' '
myCorrectedData=seperator.join(myCorrectedData)
#print(myCorrectedData)
doc = nlp(myCorrectedData)
for ent in doc.ents:
    if(ent.label_=="PERSON"):
        print(ent.text)
for token in doc:
    if(token.like_email):
        print(token.text)
tokens = [word for word in myCorrectedData.split()]
for token in tokens:
    ssnHiphen = ssnRegexWithHiphen.search(token) 
    try:
        print(ssnHiphen.group())
    except:
        pass
    ssnWithOutHiphen = ssnRegexWithOutHiphen.search(token) 
    try:
        print(ssnWithOutHiphen.group())
    except:
        pass
    dateFound = dateRegex.search(token) 
    try:
        print(dateFound.group())
    except:
        pass
    phoneNumberFound = phoneNumberRegex.search(token) 
    try:
        print(phoneNumberFound.group())
    except:
        pass
    creditCardNumberFound = creditCardNumberRegex.search(token) 
    try:
        print(creditCardNumberFound.group())
    except:
        pass


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




