import React, { Component } from "react";
import { connect } from "react-redux";
import { getContactsList } from "./actions/contactActions";

class ShowContacts extends Component {
  componentDidMount() {
    this.props.getContactsList();
  }
  render() {
    const { contactDataForCurrentComponent } = this.props;
    return (
      <div>
        {contactDataForCurrentComponent.map(contact => {
          return (
            <div>
              <div>{contact.id}</div>
              <div>{contact.name}</div>
              <div>{contact.email}</div>
              <div>{contact.phone}</div>
            </div>
          );
        })}
      </div>
    );
  }
}
const mapStateToProps = state => ({
  contactDataForCurrentComponent: state.contactData.contacts
});
export default connect(
  mapStateToProps,
  { getContactsList }
)(ShowContacts);
