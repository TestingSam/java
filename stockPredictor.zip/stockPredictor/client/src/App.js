import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Provider } from "react-redux";
import "bootstrap/dist/css/bootstrap.min.css";
import store from "./store";
import "./LeftMenu.css";
import LeftMenu from "./LeftMenu";
import AddSector from "./AddSector";

function App() {
  return (
    <Provider store={store}>
      <Router>
        <div className="App">
          <Switch>
            <Route exact path="/" component={LeftMenu} />
            <Route exact path="/ADD_SECTOR" component={AddSector} />
          </Switch>
        </div>
      </Router>
    </Provider>
  );
}

export default App;
