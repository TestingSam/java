import { GET_AVAILABLE_COMPANIES, GET_SELECTED_COMPANIES } from "./types";
import axios from "axios";

export const getCompanyNames = selectedSector => async dispatch => {
  console.log("selectedSector");
  console.log(selectedSector);
  const res = await axios.post("http://127.0.0.1:5000/getCompanies", {
    selectedSector
  });
  dispatch({
    type: GET_AVAILABLE_COMPANIES,
    payload: res.data
  });
};

export const setSelectedCompany = selectedCompanies => {
  return {
    type: GET_SELECTED_COMPANIES,
    payload: selectedCompanies
  };
};
