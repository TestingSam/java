import { SET_COLLAPSE } from "../actions/types";

const initialState = { collapseDataBool: true };

export default function(state = initialState, action) {
  switch (action.type) {
    case SET_COLLAPSE:
      return {
        ...state,
        collapseDataBool: action.payload
      };
    default:
      return state;
  }
}
