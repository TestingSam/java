import React, { Component } from "react";
import Select from "react-select";
import { connect } from "react-redux";
import {
  getSectorNames,
  setSelectedSector,
  formSelectedSectorDataTree
} from "./actions/addSectorActions";
import {
  getCompanyNames,
  setSelectedCompany
} from "./actions/addCompanyActions";

class AddSector_dropdowns extends Component {
  componentDidMount() {
    this.props.getSectorNames();
  }
  onChangeSectorHandler = selectedValues => {
    console.log(selectedValues.label);
    this.props.getCompanyNames(selectedValues);
    this.props.setSelectedSector(selectedValues.label);
  };

  onChangeCompanyHandler = selectedValues => {
    this.props.setSelectedCompany(selectedValues);
  };

  onClickHandler = (selectedSector, selectedCompanies) => {
    console.log(selectedSector);
    console.log(selectedCompanies);
    this.props.formSelectedSectorDataTree(selectedSector, selectedCompanies);
    window.location.reload();
  };

  render() {
    const {
      availableSectors,
      availableCompaniesInComponent,
      selectedSector,
      selectedCompanies,
      dataSubmitStatus
    } = this.props;
    return (
      <div>
        <div class="line" />
        <Select
          options={availableSectors}
          isSearchable
          onChange={this.onChangeSectorHandler.bind(this)}
        />
        <div class="line" />
        <Select
          options={availableCompaniesInComponent}
          isMulti
          isSearchable
          onChange={this.onChangeCompanyHandler.bind(this)}
        />
        <div class="line" />
        <button
          className="btn btn-lg btn-success"
          onClick={this.onClickHandler.bind(
            this,
            selectedSector,
            selectedCompanies
          )}
        >
          Submit
        </button>
        <div>{dataSubmitStatus}</div>
      </div>
    );
  }
}
const mapStateToProps = state => ({
  availableSectors: state.sectorPageHeader.sectors,
  availableCompaniesInComponent: state.companyPageHeader.availableCompanies,
  selectedSector: state.sectorPageHeader.selectedSector,
  selectedCompanies: state.companyPageHeader.allSelectedCompanies,
  dataSubmitStatus: state.sectorPageHeader.formSelectStatus
});
export default connect(
  mapStateToProps,
  {
    getSectorNames,
    getCompanyNames,
    setSelectedSector,
    setSelectedCompany,
    formSelectedSectorDataTree
  }
)(AddSector_dropdowns);
