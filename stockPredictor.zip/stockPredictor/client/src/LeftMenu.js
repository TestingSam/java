import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getDataForComponent,
  getSectorSplitUp,
  getLineChartInfo,
  getNewsForSector,
  setLineChartFlag,
  setBarChartFlag
} from "./actions/contactActions";
import Header from "./Header";
import SideBar from "./SideBar";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import Loader from "react-loader-spinner";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import ReactDOM from "react-dom";
import Modal from "react-modal";
const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "40%",
    bottom: "-20%",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  }
};
class LeftMenu extends Component {
  componentDidMount() {
    this.props.getDataForComponent();
    this.props.getSectorSplitUp();
  }
  constructor() {
    super();

    this.state = {
      modalIsOpen: false,
      news: [],
      header: "",
      finalSectorMessage: "",
      finalSymbolMessage: "",
      mood1: "",
      mood2: "",
      sectorSubHeading: "",
      symbolSubHeading: ""
    };

    this.openModal = this.openModal.bind(this);
    this.afterOpenModal = this.afterOpenModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  openModal() {
    this.setState({ modalIsOpen: true });
  }

  afterOpenModal() {
    // references are now sync'd and can be accessed.
    this.subtitle.style.color = "#FFF";
  }

  closeModal() {
    this.setState({ modalIsOpen: false });
  }
  render() {
    const {
      myDataFromReducer,
      splitUpInfo,
      lineChartData,
      sectorNewsSentimentData,
      lineChartFlag,
      barChartFlag
    } = this.props;
    const lineChartOptions = {
      title: {
        text: "Actual Vs Predicted"
      },
      yAxis: {
        title: {
          text: "Number of Employees"
        }
      },
      legend: {
        layout: "vertical",
        align: "right",
        verticalAlign: "middle"
      },

      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
          pointStart: 2010
        }
      },

      series: lineChartData,

      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500
            },
            chartOptions: {
              legend: {
                layout: "horizontal",
                align: "center",
                verticalAlign: "bottom"
              }
            }
          }
        ]
      }
    };
    const options = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: "pie"
      },
      title: {
        text: "Advisor's AUM Split up"
      },
      tooltip: {
        pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: "pointer",
          dataLabels: {
            enabled: true,
            format: "<b>{point.name}</b>: {point.percentage:.1f} %"
          }
        }
      },
      series: [
        {
          name: "Sectors",
          colorByPoint: true,
          data: splitUpInfo,
          point: {
            events: {
              click: function(event) {
                callExternalFunction(this.name);
              }
            }
          }
        }
      ]
    };
    const sentimentAnalysisOptions = {
      chart: {
        type: "bar"
      },
      title: {
        text: "Sentiment Analysis by Sector"
      },
      subtitle: {
        text:
          'Source: <a href="https://in.finance.yahoo.com/">YahooFinance Customized For FMR</a>'
      },
      xAxis: {
        categories: ["POSITIVE", "NEGATIVE", "NEUTRAL"],
        title: {
          text: null
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: "News (Count)",
          align: "high"
        },
        labels: {
          overflow: "justify"
        }
      },
      tooltip: {
        valueSuffix: " News"
      },
      plotOptions: {
        bar: {
          dataLabels: {
            enabled: true
          }
        }
      },
      legend: {
        layout: "vertical",
        align: "right",
        verticalAlign: "top",
        x: -40,
        y: 80,
        floating: true,
        borderWidth: 1,
        backgroundColor:
          Highcharts.defaultOptions.legend.backgroundColor || "#FFFFFF",
        shadow: true
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        series: {
          cursor: "pointer",
          point: {
            events: {
              click: function() {
                console.log(sectorNewsSentimentData);
                console.log("sectorNewsSentimentData");
                console.log(this);
                getAnalysedNews(
                  this.series.name,
                  this.category,
                  sectorNewsSentimentData
                );
              }
            }
          }
        }
      },
      series: sectorNewsSentimentData
    };
    const callExternalFunction = obj => {
      var selectedCompanies = [];
      var selectedCompanySymbols = [];
      var selectedSymbolsChecked = "";
      var checkBoxCount = document.getElementsByClassName(
        "form-check-input myCheckBox"
      ).length;
      for (var i = 0; i < checkBoxCount; i++) {
        if (
          document.getElementsByClassName("form-check-input myCheckBox")[i]
            .checked
        ) {
          selectedCompanies.push(
            document.getElementsByClassName("form-check-input myCheckBox")[i].id
          );
        }
      }
      selectedCompanies.map(company => {
        company = company.split("--")[1];
        selectedCompanySymbols.push(company);
      });

      selectedCompanySymbols.map(symbols => {
        selectedSymbolsChecked = selectedSymbolsChecked + "," + symbols;
      });
      selectedSymbolsChecked = selectedSymbolsChecked.substr(1);
      console.log("selectedSymbolsChecked");
      console.log(selectedSymbolsChecked);
      this.setState({
        mood1: "",
        mood2: "",
        symbolSubHeading: "",
        sectorSubHeading: ""
      });
      this.props.setLineChartFlag();
      this.props.setBarChartFlag();
      this.props.getLineChartInfo(obj);
      this.props.getNewsForSector(obj, selectedSymbolsChecked);
    };
    const getAnalysedNews = (category, newsType, sectorNewsSentimentData) => {
      console.log(sectorNewsSentimentData);
      if (newsType == "POSITIVE" && category.includes("sector"))
        //alert(sectorNewsSentimentData[0].positiveNews);
        this.setState({
          news: sectorNewsSentimentData[0].positiveNews,
          mood1: sectorNewsSentimentData[0].largest,
          sectorSubHeading: category
        });
      if (newsType == "NEGATIVE" && category.includes("sector"))
        this.setState({
          news: sectorNewsSentimentData[0].negativeNews,
          mood1: sectorNewsSentimentData[0].largest,
          sectorSubHeading: category
        });
      if (newsType == "NEUTRAL" && category.includes("sector"))
        this.setState({
          news: sectorNewsSentimentData[0].neutralNews,
          mood1: sectorNewsSentimentData[0].largest,
          sectorSubHeading: category
        });
      if (newsType == "POSITIVE" && category.includes("symbols"))
        this.setState({
          news: sectorNewsSentimentData[1].positiveNews,
          mood2: sectorNewsSentimentData[1].largest,
          symbolSubHeading: category
        });
      if (newsType == "NEGATIVE" && category.includes("symbols"))
        this.setState({
          news: sectorNewsSentimentData[1].negativeNews,
          mood2: sectorNewsSentimentData[1].largest,
          symbolSubHeading: category
        });
      if (newsType == "NEUTRAL" && category.includes("symbols"))
        this.setState({
          news: sectorNewsSentimentData[1].neutralNews,
          mood2: sectorNewsSentimentData[1].largest,
          symbolSubHeading: category
        });
      this.setState({ header: newsType + " News for " + category });
      this.openModal();
    };
    return (
      <div class="wrapper">
        <SideBar />
        <div id="content">
          <Header myPageHeader={myDataFromReducer} />
          <div className="container">
            <div className="row">
              <div className="col-6">
                <HighchartsReact highcharts={Highcharts} options={options} />
              </div>
              <div className="col-6">
                {lineChartFlag ? (
                  <div>
                    <HighchartsReact
                      highcharts={Highcharts}
                      options={lineChartOptions}
                    />
                  </div>
                ) : (
                  <div className="loaderSpinner">
                    <Loader
                      type="Puff"
                      color="#00BFFF"
                      height="100"
                      width="100"
                    />
                  </div>
                )}
              </div>
            </div>
            <div className="line" />
            <div className="row">
              <div className="col-8">
                {barChartFlag ? (
                  <div>
                    <HighchartsReact
                      highcharts={Highcharts}
                      options={sentimentAnalysisOptions}
                    />
                    <Modal
                      isOpen={this.state.modalIsOpen}
                      onAfterOpen={this.afterOpenModal}
                      onRequestClose={this.closeModal}
                      style={customStyles}
                      contentLabel="Example Modal"
                    >
                      <nav class="navbar navbar-dark bg-dark">
                        <a class="navbar-brand" href="#">
                          <h2 ref={subtitle => (this.subtitle = subtitle)}>
                            {this.state.header}
                          </h2>
                        </a>
                      </nav>
                      <div class="container">
                        {this.state.news.map(mykey => {
                          return (
                            <div>
                              <div class="row">
                                &nbsp;
                                <p>{mykey}</p> &nbsp;
                              </div>
                              <div class="row" />
                              &nbsp;
                            </div>
                          );
                        })}
                      </div>
                    </Modal>
                  </div>
                ) : (
                  <div className="loaderSpinner">
                    <Loader
                      type="Puff"
                      color="#00BFFF"
                      height="100"
                      width="100"
                    />
                  </div>
                )}
              </div>
              {barChartFlag ? (
                <div>
                  <div className="row">
                    {" "}
                    <div className="col-12">
                      &nbsp;
                      <h6>
                        {this.state.sectorSubHeading}
                        <i className={this.state.mood1}></i>
                      </h6>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-12">
                      &nbsp;
                      <h6>
                        {" "}
                        {this.state.symbolSubHeading}
                        <i className={this.state.mood2}></i>
                      </h6>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  myDataFromReducer: state.contact.mydata,
  splitUpInfo: state.contact.sectorSplitupInfo,
  lineChartData: state.contact.lineChart,
  sectorNewsSentimentData: state.contact.sectorOverAll,
  lineChartFlag: state.contact.lineChartFlag,
  barChartFlag: state.contact.barChartFlag
});

export default connect(
  mapStateToProps,
  {
    getDataForComponent,
    getSectorSplitUp,
    getLineChartInfo,
    getNewsForSector,
    setLineChartFlag,
    setBarChartFlag
  }
)(LeftMenu);
