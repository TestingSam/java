import React, { Component } from "react";
import { Link } from "react-router-dom";
import ReactDOM from "react-dom";
import Modal from "react-modal";
import data from "./sectorTree";
import { connect } from "react-redux";
import { deleteSector } from "./actions/addSectorActions";
const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "40%",
    bottom: "-20%",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  }
};
class Configurations extends Component {
  constructor() {
    super();

    this.state = {
      modalIsOpen: false
    };

    this.openModal = this.openModal.bind(this);
    this.afterOpenModal = this.afterOpenModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  openModal() {
    this.setState({ modalIsOpen: true });
  }

  afterOpenModal() {
    // references are now sync'd and can be accessed.
    this.subtitle.style.color = "#FFF";
  }

  closeModal() {
    this.setState({ modalIsOpen: false });
  }
  DeleteSector = sectorTobeDeleted => {
    this.props.deleteSector(sectorTobeDeleted);
  };
  render() {
    var myKeys = Object.keys(data);
    const { deletedStatusForComponent } = this.props;
    return (
      <ul class="list-unstyled CTAs">
        <ol>
          <Link to="/ADD_SECTOR" class="btn btn-success btn">
            <i class="fa fa-plus" aria-hidden="true" />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Add Sectors
          </Link>
        </ol>
        &nbsp;
        <ol>
          <Link class="btn btn-success btn" onClick={this.openModal}>
            <i class="fa fa-trash" aria-hidden="true" />
            &nbsp;&nbsp;Delete Sectors
          </Link>
        </ol>
        <div>
          <Modal
            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            style={customStyles}
            contentLabel="Example Modal"
          >
            <nav class="navbar navbar-dark bg-dark">
              <a class="navbar-brand" href="#">
                <h2 ref={subtitle => (this.subtitle = subtitle)}>
                  Delete Sector
                </h2>
              </a>
            </nav>
            <div class="container">
              {myKeys.map(mykey => {
                return (
                  <div>
                    <div class="row">
                      &nbsp;
                      <button
                        class="btn btn-info btn-lg"
                        onClick={this.DeleteSector.bind(this, mykey)}
                      >
                        {mykey}
                      </button>{" "}
                      &nbsp;
                    </div>
                    <div class="row" />
                    &nbsp;
                  </div>
                );
              })}
              <p>{deletedStatusForComponent}</p>
            </div>
          </Modal>
        </div>
      </ul>
    );
  }
}
const mapStateToProps = state => ({
  deletedStatusForComponent: state.sectorPageHeader.deletedStatus
});
export default connect(
  mapStateToProps,
  { deleteSector }
)(Configurations);
