import React, { Component } from "react";
import Configurations from "./Configurations";
import { connect } from "react-redux";
import data from "./sectorTree";
import dataForStyles from "./styleTree";
import "./sideBar.css";

class SideBar extends Component {
  render() {
    const { setCollapseDataForComponent } = this.props;
    var myKeys = Object.keys(data);
    var myKeysForStyles = Object.keys(dataForStyles);
    return (
      <React.Fragment>
        {setCollapseDataForComponent ? (
          <nav id="sidebar">
            <ul class="list-unstyled components">
              {myKeys.map(mykey => {
                return (
                  <li>
                    <a
                      href={"#" + mykey}
                      data-toggle="collapse"
                      aria-expanded="false"
                      class="dropdown-toggle"
                    >
                      {mykey}
                    </a>

                    <ul class="collapse list-unstyled" id={mykey}>
                      {data[mykey].map(myd => {
                        return (
                          <div class="container">
                            <div className="col-1">
                              <input
                                type="checkbox"
                                class="form-check-input myCheckBox"
                                id={myd}
                              />
                            </div>
                            <div className="col-11">
                              <label
                                class="form-check-label small text-left"
                                for={myd}
                              >
                                {myd}
                              </label>
                            </div>
                          </div>
                        );
                      })}
                    </ul>
                  </li>
                );
              })}
            </ul>
            <Configurations />
            <h4>
              <u>Styles</u>
            </h4>
            <ul class="list-unstyled components">
              {myKeysForStyles.map(mykey => {
                return (
                  <li>
                    <a aria-expanded="false" class="StylesNames">
                      {mykey}
                    </a>
                  </li>
                );
              })}
            </ul>
          </nav>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  setCollapseDataForComponent: state.collapseData.collapseDataBool
});

export default connect(
  mapStateToProps,
  {}
)(SideBar);
