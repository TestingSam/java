import { SET_COLLAPSE } from "./types";

export const setCollapseInfo = collapseInfo => {
  return {
    type: SET_COLLAPSE,
    payload: collapseInfo
  };
};
