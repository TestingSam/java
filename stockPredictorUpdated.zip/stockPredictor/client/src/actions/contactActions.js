import {
  GET_DATA,
  GET_SECTOR_SPLITUP,
  GET_LINECHART_DATA,
  GET_NEWS_FOR_SECTOR,
  SET_LINE_CHART_FLAG,
  SET_BAR_CHART_FLAG,
  GET_STYLES_DATA,
  SET_STYLES_FLAG
} from "./types";
import axios from "axios";

export const getDataForComponent = () => {
  return {
    type: GET_DATA
  };
};

export const getSectorSplitUp = () => async dispatch => {
  const res = await axios.get("http://localhost:5000/getSectorSplitUp");
  dispatch({
    type: GET_SECTOR_SPLITUP,
    payload: res.data
  });
};

export const getLineChartInfo = sectorReceived => async dispatch => {
  const res = await axios.post("http://localhost:5000/getLineChartInfo", {
    sectorReceived
  });
  dispatch({
    type: GET_LINECHART_DATA,
    payload: res.data
  });
};

export const getStylesHistoricalData = styleReceived => async dispatch => {
  const res = await axios.post(
    "http://localhost:5000/getStylesHistoricalData",
    {
      styleReceived
    }
  );
  dispatch({
    type: GET_STYLES_DATA,
    payload: res.data
  });
};

export const getNewsForSector = (
  sectorReceived,
  selectedSymbolsChecked
) => async dispatch => {
  const res = await axios.post("http://localhost:5000/getNewsForSector", {
    sectorReceived,
    selectedSymbolsChecked
  });
  dispatch({
    type: GET_NEWS_FOR_SECTOR,
    payload: res.data
  });
};

export const setLineChartFlag = () => {
  return {
    type: SET_LINE_CHART_FLAG
  };
};

export const setStyleChartFlag = styleName => {
  return {
    type: SET_STYLES_FLAG,
    payload: styleName
  };
};

export const setBarChartFlag = () => {
  return {
    type: SET_BAR_CHART_FLAG
  };
};
