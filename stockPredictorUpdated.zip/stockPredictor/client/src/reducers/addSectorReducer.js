import {
  GET_SECTOR_PAGE_HEADER,
  GET_SECTOR_NAMES,
  GET_SELECTED_SECTORS,
  FORM_SECTOR_TREE,
  DELETE_SECTOR
} from "../actions/types";

const initialState = {
  sector_page__Header: "ADD SECTOR",
  sectors: [],
  selectedSector: null,
  formSelectStatus: null,
  deletedStatus: null
};

export default function(state = initialState, action) {
  switch (action.type) {
    case GET_SECTOR_PAGE_HEADER:
      return {
        ...state
      };
    case GET_SECTOR_NAMES:
      return {
        ...state,
        sectors: action.payload
      };
    case GET_SELECTED_SECTORS:
      return {
        ...state,
        selectedSector: action.payload
      };
    case FORM_SECTOR_TREE:
      return {
        ...state,
        formSelectStatus: action.payload
      };
    case DELETE_SECTOR:
      return {
        ...state,
        deletedStatus: action.payload
      };
    default:
      return state;
  }
}
