import {
  GET_DATA,
  GET_SECTOR_SPLITUP,
  GET_LINECHART_DATA,
  GET_NEWS_FOR_SECTOR,
  SET_LINE_CHART_FLAG,
  SET_BAR_CHART_FLAG,
  GET_STYLES_DATA,
  SET_STYLES_FLAG
} from "../actions/types";

const initialState = {
  mydata: "Advisor's AUM Alerts",
  sectorSplitupInfo: [],
  lineChart: [],
  sectorOverAll: [],
  lineChartFlag: true,
  historicalflag: true,
  barChartFlag: true,
  historicalData: [],
  styleName: ""
};

export default function(state = initialState, action) {
  switch (action.type) {
    case GET_DATA:
      return {
        ...state
      };
    case GET_SECTOR_SPLITUP:
      return {
        ...state,
        sectorSplitupInfo: action.payload
      };
    case GET_LINECHART_DATA:
      return {
        ...state,
        lineChart: action.payload,
        lineChartFlag: true
      };

    case GET_STYLES_DATA:
      return {
        ...state,
        historicalData: action.payload,
        historicalflag: true
      };
    case GET_NEWS_FOR_SECTOR:
      return {
        ...state,
        sectorOverAll: action.payload,
        barChartFlag: true
      };
    case SET_LINE_CHART_FLAG:
      return {
        ...state,
        lineChartFlag: false
      };
    case SET_STYLES_FLAG:
      return {
        ...state,
        historicalflag: false,
        styleName: action.payload
      };
    case SET_BAR_CHART_FLAG:
      return {
        ...state,
        barChartFlag: false
      };
    default:
      return state;
  }
}
