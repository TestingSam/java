import React, { Component } from "react";
import $ from "jquery";
import { connect } from "react-redux";
import { setCollapseInfo } from "./actions/collapseAction";
import { Link } from "react-router-dom";

class Header extends Component {
  onClickHandler = setCollapseDataForComponent => {
    console.log("Before:" + setCollapseDataForComponent);
    this.props.setCollapseInfo(setCollapseDataForComponent);
  };
  render() {
    const { myPageHeader, setCollapseDataForComponent } = this.props;
    return (
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <Link
            type="button"
            id="sidebarCollapse"
            class="btn btn-info"
            onClick={this.onClickHandler.bind(
              this,
              setCollapseDataForComponent
            )}
          >
            <i class="fas fa-align-left" />
          </Link>
          &nbsp;&nbsp;&nbsp;
          <Link type="button" to="/" class="btn btn-info">
            <i class="fa fa-home" aria-hidden="true"></i>
          </Link>
          <button
            class="btn btn-dark d-inline-block d-lg-none ml-auto"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <i class="fas fa-align-justify" />
          </button>
          <div
            class="collapse navbar-collapse"
            id="navbarSupportedContent"
            onClick={this.onClickHandler.bind(this)}
          />
          <h1 class="text-light text-center">{myPageHeader}</h1>
        </div>
      </nav>
    );
  }
}

const mapStateToProps = state => ({
  setCollapseDataForComponent: !state.collapseData.collapseDataBool
});

export default connect(
  mapStateToProps,
  { setCollapseInfo }
)(Header);
