import {
  GET_SECTOR_PAGE_HEADER,
  GET_SECTOR_NAMES,
  GET_SELECTED_SECTORS,
  FORM_SECTOR_TREE,
  DELETE_SECTOR
} from "./types";
import axios from "axios";

export const getSectorHeaderName = () => {
  return {
    type: GET_SECTOR_PAGE_HEADER
  };
};

export const getSectorNames = () => async dispatch => {
  const res = await axios.get("http://127.0.0.1:5000/getSectors");
  dispatch({
    type: GET_SECTOR_NAMES,
    payload: res.data
  });
};

export const setSelectedSector = sectorSelected => {
  return {
    type: GET_SELECTED_SECTORS,
    payload: sectorSelected
  };
};

export const formSelectedSectorDataTree = (
  selectedSector,
  selectedCompanies
) => async dispatch => {
  const res = await axios.post("http://127.0.0.1:5000/formSelectedSectorTree", {
    selectedSector,
    selectedCompanies
  });
  dispatch({
    type: FORM_SECTOR_TREE,
    payload: res.data
  });
};

export const deleteSector = sectorSelected => async dispatch => {
  const res = await axios.post("http://127.0.0.1:5000/deleteSector", {
    sectorSelected
  });
  dispatch({
    type: DELETE_SECTOR,
    payload: res.data
  });
};
