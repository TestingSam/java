import React, { Component } from "react";
import Configurations from "./Configurations";
import { connect } from "react-redux";
import data from "./sectorTree";
import "./sideBar.css";

class SideBar extends Component {
  render() {
    const { setCollapseDataForComponent } = this.props;
    var myKeys = Object.keys(data);
    return (
      <React.Fragment>
        {setCollapseDataForComponent ? (
          <div id="sidebar">
            <ul class="list-unstyled components">
              {myKeys.map(mykey => {
                return (
                  <li>
                    <a
                      href={"#" + mykey}
                      data-toggle="collapse"
                      aria-expanded="false"
                      class="dropdown-toggle"
                    >
                      {mykey}
                    </a>

                    <ul class="collapse list-unstyled" id={mykey}>
                      {data[mykey].map(myd => {
                        if (myd != true) {
                          return (
                            <div class="container">
                              <div className="col-1">
                                <input
                                  type="checkbox"
                                  class="form-check-input myCheckBox"
                                  id={myd}
                                />
                              </div>
                              <div className="col-11">
                                <label
                                  class="form-check-label small text-left"
                                  for={myd}
                                >
                                  {myd}
                                </label>
                              </div>
                            </div>
                          );
                        }
                      })}
                    </ul>
                  </li>
                );
              })}
            </ul>
            <Configurations />
          </div>
        ) : null}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  setCollapseDataForComponent: state.collapseData.collapseDataBool
});

export default connect(
  mapStateToProps,
  {}
)(SideBar);
