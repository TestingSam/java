import { combineReducers } from "redux";
import contactReducer from "./contactReducer";
import addCompanyReducer from "./addCompanyReducer";
import addSectorReducer from "./addSectorReducer";
import collapseReducer from "./collapseReducer";

export default combineReducers({
  contact: contactReducer,
  companyPageHeader: addCompanyReducer,
  sectorPageHeader: addSectorReducer,
  collapseData: collapseReducer
});
