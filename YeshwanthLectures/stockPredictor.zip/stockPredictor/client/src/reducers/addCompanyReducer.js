import {
  GET_AVAILABLE_COMPANIES,
  GET_SELECTED_COMPANIES
} from "../actions/types";

const initialState = {
  availableCompanies: [],
  allSelectedCompanies: []
};

export default function(state = initialState, action) {
  switch (action.type) {
    case GET_AVAILABLE_COMPANIES:
      return {
        ...state,
        availableCompanies: action.payload
      };
    case GET_SELECTED_COMPANIES:
      return {
        ...state,
        allSelectedCompanies: action.payload
      };
    default:
      return state;
  }
}
