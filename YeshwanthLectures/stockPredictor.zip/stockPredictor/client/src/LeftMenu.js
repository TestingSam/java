import React, { Component } from "react";
import { connect } from "react-redux";
import Switch from "react-switch";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import {
  getDataForComponent,
  getSectorSplitUp,
  getLineChartInfo,
  getNewsForSector,
  setLineChartFlag,
  setBarChartFlag,
  getStylesHistoricalData,
  setStyleChartFlag
} from "./actions/contactActions";
import Header from "./Header";
import SideBar from "./SideBar";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import Loader from "react-loader-spinner";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
//import sentimentNewsData from "./sectorNewsWithSentiment";
import ReactDOM from "react-dom";
import Modal from "react-modal";
import dataForStyles from "./styleTree";
import SectorMaxSplitUpInfo from "./sectorTree";
import "./sideBar.css";
const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "40%",
    bottom: "-20%",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  }
};
class LeftMenu extends Component {
  componentDidMount() {
    this.props.getDataForComponent();
    this.props.getSectorSplitUp("none");
    var propsContext = this.props;
    var currentContext = this;
    var styleLength = document.getElementsByClassName("StylesNames").length;
    for (var i = 0; i < styleLength; i++) {
      document
        .getElementsByClassName("StylesNames")
        [i].addEventListener("click", function() {
          propsContext.setStyleChartFlag(this.innerText);
          console.log(this.innerText);
          propsContext.getStylesHistoricalData(this.innerText);
          currentContext.setState({ stylesData: true });
          currentContext.setState({ newsSentiment: false });
          currentContext.openModal();
        });
    }
  }
  onClickStylesHandler = styleReceived => {
    //alert(styleReceived);
    this.props.setStyleChartFlag(styleReceived);
    this.props.getStylesHistoricalData(styleReceived);
    this.setState({ stylesData: true });
    this.setState({ newsSentiment: false });
  };
  constructor() {
    super();

    this.state = {
      modalIsOpen: false,
      news: [],
      header: "",
      finalSectorMessage: "",
      finalSymbolMessage: "",
      mood1: "",
      mood2: "",
      sectorSubHeading: "",
      symbolSubHeading: "",
      stylesData: false,
      newsSentiment: false,
      sectorName: "",
      Energy: 10,
      Financial: 20,
      Healthcare: 30,
      Technology: 40,
      Communication_Services: 50,
      Real_Estate: 60,
      first: true
    };

    this.openModal = this.openModal.bind(this);
    this.afterOpenModal = this.afterOpenModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  openModal() {
    this.setState({ modalIsOpen: true });
  }

  afterOpenModal() {
    // references are now sync'd and can be accessed.
    this.subtitle.style.color = "#FFF";
  }

  closeModal() {
    this.setState({ modalIsOpen: false });
  }
  handleChangeSwitch = sectorReceived => {
    console.log(sectorReceived);
    this.props.getSectorSplitUp(sectorReceived);
  };
  render() {
    var newsplitUpInfo;
    var LeftMenuContext;
    LeftMenuContext = this;
    const {
      myDataFromReducer,
      splitUpInfo,
      lineChartData,
      sectorNewsSentimentData,
      lineChartFlag,
      barChartFlag,
      historicalDataForStyles,
      historicalflag,
      styleNameForComponent,
      setCollapseDataForComponent
    } = this.props;
    var myKeysForStyles = Object.keys(dataForStyles);
    const lineChartOptions = {
      title: {
        text: "Sector Trends ~ Actual Vs Predicted"
      },
      yAxis: {
        title: {
          text: "Stock Opening Price"
        }
      },
      legend: {
        layout: "vertical",
        align: "right",
        verticalAlign: "middle"
      },
      xAxis: {
        categories: [""],
        title: {
          text: null
        },
        labels: {
          enabled: false //default is true
        }
      },

      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
          pointStart: 2010
        }
      },

      series: lineChartData,

      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500
            },
            chartOptions: {
              legend: {
                layout: "horizontal",
                align: "center",
                verticalAlign: "bottom"
              }
            }
          }
        ]
      }
    };
    const lineChartOptionsStyle = {
      title: {
        text: "Actual Vs Predicted"
      },
      yAxis: {
        title: {
          text: "Stock Opening Price"
        }
      },
      legend: {
        layout: "vertical",
        align: "right",
        verticalAlign: "middle"
      },
      xAxis: {
        categories: [""],
        title: {
          text: null
        },
        labels: {
          enabled: false //default is true
        }
      },

      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
          pointStart: 2010
        }
      },

      series: historicalDataForStyles,

      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500
            },
            chartOptions: {
              legend: {
                layout: "horizontal",
                align: "center",
                verticalAlign: "bottom"
              }
            }
          }
        ]
      }
    };
    if (splitUpInfo.length > 0) {
      //console.log(splitUpInfo);
      newsplitUpInfo = splitUpInfo.filter(info => {
        return info.flag == true;
      });
    }
    console.log(newsplitUpInfo);
    const options = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: "pie",
        events: {
          load: function() {
            console.log("Chart loading");
            var sectorsAdded = Object.keys(SectorMaxSplitUpInfo);
            console.log(SectorMaxSplitUpInfo);
            console.log(sectorsAdded);
            if (sectorsAdded.includes("Real_Estate")) {
              callExternalFunction("Real_Estate");
            } else if (sectorsAdded.includes("Communication_Services")) {
              callExternalFunction("Communication_Services");
            } else if (sectorsAdded.includes("Technology")) {
              callExternalFunction("Technology");
            } else if (sectorsAdded.includes("Healthcare")) {
              callExternalFunction("Healthcare");
            } else if (sectorsAdded.includes("Financial")) {
              callExternalFunction("Financial");
            } else if (sectorsAdded.includes("Energy")) {
              callExternalFunction("Energy");
            }
          }
        }
      },
      title: {
        text: "Advisor's AUM Split up"
      },
      tooltip: {
        pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: "pointer",
          size: 120,
          dataLabels: {
            enabled: true,
            format: "<b>{point.name}</b>: {point.percentage:.1f} %"
          }
        }
      },
      series: [
        {
          name: "Sectors",
          colorByPoint: true,
          data: newsplitUpInfo,
          point: {
            events: {
              click: function(event) {
                callExternalFunction(this.name);
              }
            }
          }
        }
      ]
    };

    //Bar chart Code
    const sentimentAnalysisOptions = {
      chart: {
        type: "bar",
        events: {
          load: function() {
            //alert("Bar Chart Loaded Successfully");
            if (!LeftMenuContext.state.newsSentiment) {
              console.log(sectorNewsSentimentData);
              console.log(" afterAnimate sectorNewsSentimentData");
              //console.log(this.category);
              getAnalysedMood(sectorNewsSentimentData);
              LeftMenuContext.setState({ newsSentiment: true });
            }
          }
        }
      },
      title: {
        text: "Sentiment Analysis by Sector"
      },
      subtitle: {
        text:
          'Source: <a href="https://in.finance.yahoo.com/">YahooFinance Customized For FMR</a>'
      },
      xAxis: {
        categories: ["POSITIVE", "NEGATIVE", "NEUTRAL"],
        title: {
          text: null
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: "News (Count)",
          align: "high"
        },
        labels: {
          overflow: "justify"
        }
      },
      tooltip: {
        formatter: function() {
          var a = this.series.yData;
          var sum = a.reduce(function(a, b) {
            return a + b;
          }, 0);
          return (
            "<b>" +
            this.y +
            " news </b><br/>" +
            Math.round((this.y / sum) * 100) +
            " percent"
          );
        }
      },
      plotOptions: {
        bar: {
          dataLabels: {
            enabled: true
          }
        }
      },
      legend: {
        align: "right",
        verticalAlign: "top",
        layout: "vertical",
        x: 0,
        y: 0
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        series: {
          cursor: "pointer",
          events: {
            afterAnimate: function() {
              if (LeftMenuContext.state.first) {
                console.log(sectorNewsSentimentData);
                console.log(" afterAnimate sectorNewsSentimentData");
                //console.log(this.category);
                getAnalysedMood(sectorNewsSentimentData);
                LeftMenuContext.setState({ first: false });
              }
            }
          },
          point: {
            events: {
              click: function() {
                //console.log(sectorNewsSentimentData);
                //console.log("sectorNewsSentimentData");
                console.log(this);
                getAnalysedNews(
                  this.series.name,
                  this.category,
                  sectorNewsSentimentData
                );
                getAnalysedMood(sectorNewsSentimentData);
              }
            }
          }
        }
      },
      series: sectorNewsSentimentData
    };
    const callExternalFunction = obj => {
      var selectedCompanies = [];
      var selectedCompanySymbols = [];
      var selectedSymbolsChecked = "";
      var checkBoxCount = document.getElementsByClassName(
        "form-check-input myCheckBox"
      ).length;
      for (var i = 0; i < checkBoxCount; i++) {
        if (
          document.getElementsByClassName("form-check-input myCheckBox")[i]
            .checked
        ) {
          selectedCompanies.push(
            document.getElementsByClassName("form-check-input myCheckBox")[i].id
          );
        }
      }
      selectedCompanies.map(company => {
        company = company.split("--")[1];
        selectedCompanySymbols.push(company);
      });

      selectedCompanySymbols.map(symbols => {
        selectedSymbolsChecked = selectedSymbolsChecked + "," + symbols;
      });
      selectedSymbolsChecked = selectedSymbolsChecked.substr(1);
      console.log("Clicked Sector selectedSymbolsChecked");
      console.log(selectedSymbolsChecked);
      this.setState({
        mood1: "",
        mood2: "",
        symbolSubHeading: "",
        sectorSubHeading: "",
        newsSentiment: false
      });
      this.props.setLineChartFlag();
      this.props.setBarChartFlag();
      this.props.getLineChartInfo(obj);
      this.props.getNewsForSector(obj, selectedSymbolsChecked);
    };
    const getAnalysedNews = (category, newsType, sectorNewsSentimentData) => {
      console.log(sectorNewsSentimentData);
      if (newsType == "POSITIVE" && category.includes("sector"))
        //alert(sectorNewsSentimentData[0].positiveNews);
        this.setState({
          news: sectorNewsSentimentData[0].positiveNews,
          sectorSubHeading: category
        });
      if (newsType == "NEGATIVE" && category.includes("sector"))
        this.setState({
          news: sectorNewsSentimentData[0].negativeNews,
          sectorSubHeading: category
        });
      if (newsType == "NEUTRAL" && category.includes("sector"))
        this.setState({
          news: sectorNewsSentimentData[0].neutralNews,
          sectorSubHeading: category
        });
      if (newsType == "POSITIVE" && category.includes("symbols"))
        this.setState({
          news: sectorNewsSentimentData[1].positiveNews,
          symbolSubHeading: category
        });
      if (newsType == "NEGATIVE" && category.includes("symbols"))
        this.setState({
          news: sectorNewsSentimentData[1].negativeNews,
          symbolSubHeading: category
        });
      if (newsType == "NEUTRAL" && category.includes("symbols"))
        this.setState({
          news: sectorNewsSentimentData[1].neutralNews,
          symbolSubHeading: category
        });
      this.setState({ header: newsType + " News for " + category });
      this.openModal();
    };

    const getAnalysedMood = sectorNewsSentimentData => {
      try {
        console.log("sectorNewsSentimentData.length");
        console.log(this.state.newsSentiment);

        console.log(sectorNewsSentimentData);
        this.setState({
          mood1: sectorNewsSentimentData[0].largest,
          sectorSubHeading: sectorNewsSentimentData[0].name
        });
        if (sectorNewsSentimentData.length > 1) {
          this.setState({
            mood2: sectorNewsSentimentData[1].largest,
            sectorSubHeading: sectorNewsSentimentData[1].name
          });
        }
      } catch (err) {}
    };

    return (
      <React.Fragment>
        <div class="wrapper container-fluid">
          <div id="content">
            <Header myPageHeader={myDataFromReducer} />
            <div className="container-fluid sectorSplit">
              <SideBar />
              <div className="row ">
                <div className="col-md-12">
                  <HighchartsReact highcharts={Highcharts} options={options} />
                  {splitUpInfo.map(split => {
                    var sectorName = split.name;
                    return (
                      <label>
                        <span>{split.name}</span>
                        <Switch
                          onChange={this.handleChangeSwitch.bind(
                            this,
                            sectorName
                          )}
                          name={sectorName}
                          checked={split.flag}
                          onColor="#86d3ff"
                          onHandleColor="#2693e6"
                          handleDiameter={20}
                          uncheckedIcon={false}
                          checkedIcon={false}
                          boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
                          activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
                          height={10}
                          width={28}
                          className="react-switch"
                          id="material-switch"
                        />
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid">
          <Tabs forceRenderTabPanel defaultIndex={1}>
            <TabList>
              <Tab>Sector Trends</Tab>
              <Tab>News Sentiment Analysis</Tab>
              <Tab
                onClick={this.onClickStylesHandler.bind(this, "Mid_Cap_Growth")}
              >
                Styles Trends
              </Tab>
            </TabList>

            <TabPanel>
              <div className="col-md-12">
                {lineChartFlag ? (
                  <div>
                    <HighchartsReact
                      highcharts={Highcharts}
                      options={lineChartOptions}
                    />
                  </div>
                ) : (
                  <div className="loaderSpinner">
                    <Loader
                      type="Puff"
                      color="#00BFFF"
                      height="100"
                      width="100"
                    />
                  </div>
                )}
              </div>
            </TabPanel>
            <TabPanel>
              <div className="row">
                <div className="col-md-9">
                  {barChartFlag ? (
                    <div>
                      <HighchartsReact
                        highcharts={Highcharts}
                        options={sentimentAnalysisOptions}
                      />
                      <Modal
                        isOpen={this.state.modalIsOpen}
                        onAfterOpen={this.afterOpenModal}
                        onRequestClose={this.closeModal}
                        style={customStyles}
                        contentLabel="Example Modal"
                      >
                        {this.state.newsSentiment ? (
                          <React.Fragment>
                            <nav class="navbar navbar-dark bg-dark">
                              <a class="navbar-brand" href="#">
                                <h2
                                  ref={subtitle => (this.subtitle = subtitle)}
                                >
                                  {this.state.header}
                                </h2>
                              </a>
                            </nav>
                            <div class="container">
                              {this.state.news.map(mykey => {
                                return (
                                  <div>
                                    <div class="row">
                                      &nbsp;
                                      <p>{mykey}</p> &nbsp;
                                    </div>
                                    <div class="row" />
                                    &nbsp;
                                  </div>
                                );
                              })}
                            </div>
                          </React.Fragment>
                        ) : null}
                      </Modal>
                    </div>
                  ) : (
                    <div className="loaderSpinner">
                      <Loader
                        type="Puff"
                        color="#00BFFF"
                        height="100"
                        width="100"
                      />
                    </div>
                  )}
                </div>
                {barChartFlag ? (
                  <div>
                    <div className="row">
                      {" "}
                      <div className="col-12">
                        &nbsp;
                        <h6>
                          {this.state.sectorSubHeading}
                          <i className={this.state.mood1}></i>
                        </h6>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12">
                        &nbsp;
                        <h6>
                          {" "}
                          {this.state.symbolSubHeading}
                          <i className={this.state.mood2}></i>
                        </h6>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            </TabPanel>
            <TabPanel>
              <Tabs forceRenderTabPanel>
                <TabList>
                  {myKeysForStyles.map(mykey => {
                    return (
                      <Tab
                        onClick={this.onClickStylesHandler.bind(this, mykey)}
                      >
                        {mykey}
                      </Tab>
                    );
                  })}
                </TabList>
                {myKeysForStyles.map(mykey => {
                  return (
                    <TabPanel>
                      {this.state.stylesData ? (
                        <React.Fragment>
                          <nav class="navbar navbar-dark bg-dark">
                            <a class="navbar-brand" href="#">
                              <h2 ref={subtitle => (this.subtitle = subtitle)}>
                                {styleNameForComponent}
                              </h2>
                            </a>
                          </nav>
                          <div class="container">
                            <div className="col-12">
                              {historicalflag ? (
                                <div>
                                  <HighchartsReact
                                    highcharts={Highcharts}
                                    options={lineChartOptionsStyle}
                                  />
                                </div>
                              ) : (
                                <div className="loaderSpinner">
                                  <Loader
                                    type="Puff"
                                    color="#00BFFF"
                                    height="100"
                                    width="100"
                                  />
                                </div>
                              )}
                            </div>
                          </div>
                        </React.Fragment>
                      ) : null}
                    </TabPanel>
                  );
                })}
              </Tabs>
            </TabPanel>
          </Tabs>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  myDataFromReducer: state.contact.mydata,
  splitUpInfo: state.contact.sectorSplitupInfo,
  lineChartData: state.contact.lineChart,
  sectorNewsSentimentData: state.contact.sectorOverAll,
  lineChartFlag: state.contact.lineChartFlag,
  barChartFlag: state.contact.barChartFlag,
  historicalDataForStyles: state.contact.historicalData,
  historicalflag: state.contact.historicalflag,
  styleNameForComponent: state.contact.styleName,
  setCollapseDataForComponent: state.collapseData.collapseDataBool
});

export default connect(
  mapStateToProps,
  {
    getDataForComponent,
    getSectorSplitUp,
    getLineChartInfo,
    getNewsForSector,
    setLineChartFlag,
    setBarChartFlag,
    getStylesHistoricalData,
    setStyleChartFlag
  }
)(LeftMenu);
