import React, { Component } from "react";
import Header from "./Header";
import SideBar from "./SideBar";
import { connect } from "react-redux";
import { getSectorHeaderName } from "./actions/addSectorActions";
import AddSector_dropdowns from "./AddSector_dropdowns";

class AddSector extends Component {
  componentDidMount() {
    this.props.getSectorHeaderName();
  }
  render() {
    const { pageHeader } = this.props;
    return (
      <div class="wrapper">
        <div id="content">
          <Header myPageHeader={pageHeader} />
          <AddSector_dropdowns />
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  pageHeader: state.sectorPageHeader.sector_page__Header
});

export default connect(
  mapStateToProps,
  { getSectorHeaderName }
)(AddSector);
