#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import operator
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import re
from keras.models import Sequential, load_model
from keras.layers import LSTM, Dense, Embedding, Dropout
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences


# In[2]:


dataset = pd.read_csv(r'D:\shinu\stockPredictor\News.csv', encoding = "ISO-8859-1")
dataset = dataset.sample(frac=1).reset_index(drop=True)
dataset.head()


# In[3]:


dataset['text'].apply(lambda x: x.lower())
dataset['text'] = dataset['text'].apply(lambda x: re.sub('[^a-zA-Z0-9\s]',"",x))
dataset['text'].head()


# In[4]:


tokenizer = Tokenizer(num_words=1000, split=" ")
tokenizer.fit_on_texts(dataset['text'].values)

X = tokenizer.texts_to_sequences(dataset['text'].values)
X = pad_sequences(X, maxlen=15)
X[:7]


# In[5]:


model = load_model(r'D:\shinu\stockPredictor\Sentiment_Model.h5')


# In[6]:


prediction = model.predict(X)
news=[]
label=[]
for i in range(0,dataset.shape[0]):
    news.append(dataset['text'][i])
    if(max(enumerate(prediction[i]), key=operator.itemgetter(1))[0]==0):
        label.append("1")
    elif(max(enumerate(prediction[i]), key=operator.itemgetter(1))[0]==1):
        label.append("0")
    elif(max(enumerate(prediction[i]), key=operator.itemgetter(1))[0]==2):
        label.append("-1")
dict = {'headline': news, 'label': label}
df = pd.DataFrame(dict)
df.to_csv(r'D:\shinu\stockPredictor\newsSentiments.csv', index=False) 
df.to_csv(r'D:\shinu\stockPredictor\newsSentimentsCollection.csv', mode='a', header=None, index=False)


# In[ ]:




