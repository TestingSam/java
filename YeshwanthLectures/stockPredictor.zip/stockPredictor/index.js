const express = require("express");
var bodyParser = require("body-parser");
const app = express();
const cors = require("cors");
var yahooFinance = require("yahoo-finance");
var mydate = require("current-date");
var csvWriter = require("csv-write-stream");
const fs = require("fs");
const fsextra = require("fs-extra");
const exec = require("child_process").exec;
var readTextFile = require("read-text-file");
const jsonfile = require("jsonfile");
var csvsync = require("csvsync");
var pythonCmd2 = 'python "Sentiment Analysis.py"';
var pythonCmd3 = 'python "Sentiment Analysis2.py"';
var pythonCmd = 'python "Stock price prediction.py"';
var pythonCmd4 = 'python "Stock price predictionStyles.py"';
var Excel = require("exceljs");
var workbook = new Excel.Workbook();
const port = process.env.PORT || 5000;
var sectorFilename = "D:\\shinu\\stockPredictor\\Sectors.xlsx";
var stylesFilename = "D:\\shinu\\stockPredictor\\Styles.xlsx";
var sectorTree = "D:\\shinu\\stockPredictor\\client\\src\\sectorTree.json";
var styleTree = "D:\\shinu\\stockPredictor\\client\\src\\styleTree.json";
var sectorNewsWithSentiment =
  "D:\\shinu\\stockPredictor\\client\\src\\sectorNewsWithSentiment.json";
sectorTreeDataCollection = jsonfile.readFileSync(sectorTree);
styleTreeDataCollection = jsonfile.readFileSync(styleTree);
var yahooFinanceNews = require("yahoo-finance-news");
var selectionTree = {};
var sentimentNewsFile = "D:\\shinu\\stockPredictor\\News.csv";
var sentimentNewsFileCollection =
  "D:\\shinu\\stockPredictor\\NewsCollection.csv";
var sentimentNewsFileSpecific = "D:\\shinu\\stockPredictor\\NewsSpecific.csv";
var EnergyAlloc = 10;
var FinancialAlloc = 20;
var HealthcareAlloc = 30;
var TechnologyAlloc = 40;
var Communication_ServicesAlloc = 50;
var Real_EstateAlloc = 60;

/*yahooFinanceNews.get("AMOV", function(newsCollection) {
  console.log("YAHOO NEWS");
  var newsCollection = JSON.parse(newsCollection);
  newsCollection.map(news => {
    console.log(news.items);
  });
});*/

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// console.log that your server is up and running
app.listen(port, () => console.log(`Listening on port ${port}`));

var styles = {};
var workSheetCounterWithStyles = 0;
var workSheetNamesWithStyles = [];
workbook.xlsx.readFile(stylesFilename).then(function() {
  workbook.eachSheet(function(worksheet, sheetId) {
    workSheetCounterWithStyles++;
    var workSheetName = "";
    workSheetName = worksheet.name;
    workSheetNamesWithStyles.push(workSheetName);
    var sector_company_Data_withStyles = [];
    var worksheetWithStyles = workbook.getWorksheet(workSheetName);
    var lastRowWithStyle = worksheetWithStyles.lastRow._number;
    worksheetWithStyles.eachRow({ includeEmpty: true }, function(
      row,
      rowNumber
    ) {
      sector_company_Data_withStyles.push(row.values[2] + "--" + row.values[1]);
      if (lastRowWithStyle == rowNumber) {
        styles[workSheetName] = sector_company_Data_withStyles;
      }
    });
    if (workSheetCounterWithStyles == workbook.worksheets.length) {
      //console.log(styles);
      jsonfile.writeFileSync(styleTree, styles);
    }
  });
});

// create a GET route
app.get("/express_backend", (req, res) => {
  res.send({ express: "YOUR EXPRESS BACKEND IS CONNECTED TO REACT" });
});

app.post("/getStylesHistoricalData", (req, res) => {
  //console.log(req.body.styleReceived);
  var styleTreeData = jsonfile.readFileSync(styleTree);
  //console.log(styleTreeData[req.body.styleReceived]);
  var dataToBeSent = [];
  var collateData = [];
  var companySymbols = [];
  console.log(req.body.sectorReceived);
  var sectorReceived = req.body.styleReceived;
  var sectorTreeData = jsonfile.readFileSync(styleTree);
  sectorTreeData[sectorReceived].map(company => {
    companySymbols.push(company.split("--")[1]);
  });
  yahooFinance.historical(
    {
      symbols: companySymbols,
      from: "2012-06-10",
      to: "2019-06-20"
    },
    function(err, results) {
      var keys = Object.keys(results);
      keys.map(key => {
        i = 0;
        results[key].map(company => {
          if (typeof collateData[i] === "undefined") {
            collateData[i] = company.open;
          } else {
            collateData[i] = collateData[i] + company.open;
          }
          i = i + 1;
        });
      });
      var writer = csvWriter();
      writer.pipe(fs.createWriteStream(__dirname + "/" + "AAPLSTYLES.csv"));
      for (var k = collateData.length - 1; k > 0; k--) {
        if (!isNaN(collateData[k])) writer.write({ open: collateData[k] });
      }
      writer.end();
      exec(pythonCmd4, function(error, stdout, stderr) {
        var actual = {};
        var actualDataArray = [];
        var predictedDataArray = [];
        var predicted = {};
        actual.name = "Actual";
        actualDataCollection = readTextFile.readSync("guru99styles.txt");
        actualDataCollection.split(",").map(actualData => {
          actualData = parseFloat(actualData);
          actualDataArray.push(actualData);
        });
        predicted.name = "Predicted";
        predictedDataCollection = readTextFile.readSync("guru99_1styles.txt");
        predictedDataCollection.split(",").map(predictedData => {
          predictedData = parseFloat(predictedData);
          predictedDataArray.push(predictedData);
        });
        //console.log("predictedDataArray");
        //console.log(predictedDataArray);
        //console.log("predictedDataArray First Element");
        //console.log(predictedDataArray[0]);
        actual.data = actualDataArray;
        predicted.data = predictedDataArray;
        actual.visible = true;
        predicted.visible = false;
        console.log(predictedDataArray[0]);
        console.log(2000 + actualDataArray.length);
        predicted.pointStart =
          (predictedDataArray[0], 2000 + actualDataArray.length);
        dataToBeSent.push(actual);
        dataToBeSent.push(predicted);
        console.log("DONE REQUEST..");
        res.send(dataToBeSent);
      });
    }
  );
});

app.post("/getCompanies", (req, res) => {
  var sector_company_Data = [];
  workbook.xlsx.readFile(sectorFilename).then(function() {
    var worksheet = workbook.getWorksheet(req.body.selectedSector.label);
    var lastRow = worksheet.lastRow._number;
    worksheet.eachRow({ includeEmpty: true }, function(row, rowNumber) {
      var companyDetails = {};
      companyDetails.value = row.values[1];
      companyDetails.label = row.values[2] + "--" + row.values[1];
      sector_company_Data.push(companyDetails);
      if (lastRow == rowNumber) {
        res.send(sector_company_Data);
      }
    });
  });
});

app.post("/getSectorSplitUp", (req, res) => {
  console.log(req.body.sectorReceived);
  var Allocation = 100;
  var sectorSplitUpDataResponse = [];
  var splitUpRatio = 0;
  var sectorTreeData = jsonfile.readFileSync(sectorTree);
  sectorTreeNodes = Object.keys(sectorTreeData);
  splitUpRatio = Allocation / sectorTreeNodes.length;
  sectorTreeNodes.map(sectorTreeNode => {
    var tempNode = {};
    tempNode.name = sectorTreeNode;
    switch (sectorTreeNode) {
      case "Energy":
        tempNode.y = EnergyAlloc;
        break;
      case "Financial":
        tempNode.y = FinancialAlloc;
        break;
      case "Healthcare":
        tempNode.y = HealthcareAlloc;
        break;
      case "Technology":
        tempNode.y = TechnologyAlloc;
        break;
      case "Communication_Services":
        tempNode.y = Communication_ServicesAlloc;
        break;
      case "Real_Estate":
        tempNode.y = Real_EstateAlloc;
        break;
      default:
        tempNode.y = Math.floor(Math.random() * 90) + 10;
    }
    tempNode.flag =
      sectorTreeData[sectorTreeNode][sectorTreeData[sectorTreeNode].length - 1];
    sectorSplitUpDataResponse.push(tempNode);
  });
  sectorSplitUpDataResponse.map(data => {
    if (data.name === req.body.sectorReceived) {
      data.flag = !data.flag;
      sectorTreeData[data.name][sectorTreeData[data.name].length - 1] =
        data.flag;
      jsonfile.writeFileSync(sectorTree, sectorTreeData);
    }
  });
  res.send(sectorSplitUpDataResponse);
});

app.get("/getSectors", (req, res) => {
  var workSheetCounter = 0;
  var workSheetNames = [];
  workbook.xlsx.readFile(sectorFilename).then(function() {
    workbook.eachSheet(function(worksheet, sheetId) {
      workSheetCounter++;
      var NodeData = {};
      NodeData.label = worksheet.name;
      NodeData.value = worksheet.name;
      workSheetNames.push(NodeData);
      if (workSheetCounter == workbook.worksheets.length)
        res.send(workSheetNames);
    });
  });
});

app.post("/formSelectedSectorTree", (req, res) => {
  console.log(req.body.selectedSector);
  companies = req.body.selectedCompanies.map(selectedCompany => {
    var company = [];
    company.push(selectedCompany.label);
    return company[0];
  });
  companies.push(true);
  selectionTree[req.body.selectedSector] = companies;
  jsonfile.writeFileSync(sectorTree, selectionTree);
  res.send("Data Submitted...");
});

app.post("/getLineChartInfo", (req, res) => {
  var dataToBeSent = [];
  var collateData = [];
  var companySymbols = [];
  console.log(req.body.sectorReceived);
  var sectorReceived = req.body.sectorReceived;
  var sectorTreeData = jsonfile.readFileSync(sectorTree);
  sectorTreeData[sectorReceived].map(company => {
    console.log("company--->" + company);
    if (company != true && company != false)
      companySymbols.push(company.split("--")[1]);
  });
  yahooFinance.historical(
    {
      symbols: companySymbols,
      from: "2012-06-10",
      to: "2019-06-20"
    },
    function(err, results) {
      var keys = Object.keys(results);
      keys.map(key => {
        i = 0;
        results[key].map(company => {
          if (typeof collateData[i] === "undefined") {
            collateData[i] = company.open;
          } else {
            collateData[i] = collateData[i] + company.open;
          }
          i = i + 1;
        });
      });
      var writer = csvWriter();
      writer.pipe(fs.createWriteStream(__dirname + "/" + "AAPL.csv"));
      for (var k = collateData.length - 1; k > 0; k--) {
        if (!isNaN(collateData[k])) writer.write({ open: collateData[k] });
      }
      writer.end();
      exec(pythonCmd, function(error, stdout, stderr) {
        var actual = {};
        var actualDataArray = [];
        var predictedDataArray = [];
        var predicted = {};
        actual.name = "Actual";
        actualDataCollection = readTextFile.readSync("guru99.txt");
        actualDataCollection.split(",").map(actualData => {
          actualData = parseFloat(actualData);
          actualDataArray.push(actualData);
        });
        predicted.name = "Predicted";
        predictedDataCollection = readTextFile.readSync("guru99_1.txt");
        predictedDataCollection.split(",").map(predictedData => {
          predictedData = parseFloat(predictedData);
          predictedDataArray.push(predictedData);
        });
        //console.log("predictedDataArray");
        //console.log(predictedDataArray);
        //console.log("predictedDataArray First Element");
        //console.log(predictedDataArray[0]);
        actual.data = actualDataArray;
        predicted.data = predictedDataArray;
        actual.visible = true;
        predicted.visible = false;
        console.log(predictedDataArray[0]);
        console.log(2000 + actualDataArray.length);
        predicted.pointStart =
          (predictedDataArray[0], 2000 + actualDataArray.length);
        dataToBeSent.push(actual);
        dataToBeSent.push(predicted);
        console.log("DONE REQUEST..");
        res.send(dataToBeSent);
      });
    }
  );
});

app.post("/getNewsForSector", (req, res) => {
  var dataToBeSent = [];
  var collateData = [];
  var companySymbols = "";
  fs.unlinkSync(sentimentNewsFile);
  fsextra.ensureFileSync(sentimentNewsFile);
  let writeStream = fs.createWriteStream(sentimentNewsFile);
  writeStream.write("text" + "\n");
  console.log("Sector Chosen");
  //console.log(req.body.sectorReceived);
  var sectorReceived = req.body.sectorReceived;
  var selectedSymbolsChecked = req.body.selectedSymbolsChecked;
  console.log("selectedSymbolsChecked-->" + selectedSymbolsChecked);
  var sectorTreeData = jsonfile.readFileSync(sectorTree);
  sectorTreeData[sectorReceived].map(company => {
    //companySymbols.push(company.split("--")[1]);
    if (company != true && company != false)
      companySymbols = companySymbols + "," + company.split("--")[1];
  });
  companySymbols = companySymbols.substr(1);
  //console.log("companySymbols--->" + companySymbols);
  yahooFinanceNews.get(companySymbols, function(newsCollection) {
    console.log("YAHOO NEWS");
    var newsCollection = JSON.parse(newsCollection);
    newsCollection.map(news => {
      //console.log(news.items);
      news.items.map(newsItem => {
        var newsMine = newsItem.title;
        newsMine = newsMine
          .replaceAll(",", "")
          .replaceAll("'", "")
          .replaceAll('"', "");
        writeStream.write(newsMine + "\n");
      });
    });
    writeStream.end();
    exec(pythonCmd2, function(error, stdout, stderr) {
      var dataSent = {};
      var positiveNews = [];
      var negtiveNews = [];
      var neutralNews = [];
      var csv = fs.readFileSync(__dirname + "\\newsSentiments.csv");
      var dataFromCSV = csvsync.parse(csv);
      for (var i = 0; i < dataFromCSV.length; i++) {
        if (dataFromCSV[i][1] == 0) neutralNews.push(dataFromCSV[i][0]);
        if (dataFromCSV[i][1] == -1) negtiveNews.push(dataFromCSV[i][0]);
        if (dataFromCSV[i][1] == 1) positiveNews.push(dataFromCSV[i][0]);
      }
      var myTempNode = {};
      var largest = "";
      var sentimentScores = [
        positiveNews.length,
        negtiveNews.length,
        neutralNews.length
      ];
      var num1, num2, num3;
      num1 = positiveNews.length;
      num2 = negtiveNews.length;
      num3 = neutralNews.length;

      if (num1 > num2 && num1 > num3) {
        largest = "fas fa-long-arrow-alt-up";
      } else if (num2 > num1 && num2 > num3) {
        largest = "fas fa-long-arrow-alt-down";
      } else if (num3 > num1 && num3 > num1) {
        largest = "fas fa-arrows-alt-h";
      }
      console.log(largest);
      var positiveNewsTemp = [];
      var negtiveNewsTemp = [];
      var neutralNewsTemp = [];
      positiveNewsTemp.push(positiveNews[0]);
      positiveNewsTemp.push(positiveNews[1]);
      negtiveNewsTemp.push(negtiveNews[0]);
      negtiveNewsTemp.push(negtiveNews[1]);
      neutralNewsTemp.push(neutralNews[0]);
      neutralNewsTemp.push(neutralNews[1]);
      positiveNews = positiveNewsTemp;
      negtiveNews = negtiveNewsTemp;
      neutralNews = neutralNewsTemp;
      myTempNode.name = sectorReceived + " sector";
      myTempNode.data = sentimentScores;
      myTempNode.positiveNews = positiveNews;
      myTempNode.negativeNews = negtiveNews;
      myTempNode.neutralNews = neutralNews;
      myTempNode.largest = largest;
      dataToBeSent.push(myTempNode);
      //console.log(myTempNode);

      if (selectedSymbolsChecked.length != 0) {
        fs.unlinkSync(sentimentNewsFileSpecific);
        fsextra.ensureFileSync(sentimentNewsFileSpecific);
        let writeStream1 = fs.createWriteStream(sentimentNewsFileSpecific);
        yahooFinanceNews.get(selectedSymbolsChecked, function(newsCollection1) {
          console.log("YAHOO NEWS");
          var newsCollection1 = JSON.parse(newsCollection1);
          newsCollection1.map(news1 => {
            //console.log(news.items);
            news1.items.map(newsItem1 => {
              var newsMine = newsItem1.title;
              newsMine = newsMine
                .replaceAll(",", "")
                .replaceAll("'", "")
                .replaceAll('"', "");
              writeStream.write(newsMine + "\n");
            });
          });
          writeStream1.end();
          exec(pythonCmd3, function(error, stdout, stderr) {
            var dataSent = {};
            var positiveNews1 = [];
            var negtiveNews1 = [];
            var neutralNews1 = [];
            var csv1 = fs.readFileSync(
              __dirname + "\\newsSentimentsSpecific.csv"
            );
            var dataFromCSV1 = csvsync.parse(csv1);
            for (var i = 0; i < dataFromCSV1.length; i++) {
              if (dataFromCSV1[i][1] == 0)
                neutralNews1.push(dataFromCSV1[i][0]);
              if (dataFromCSV1[i][1] == -1)
                negtiveNews1.push(dataFromCSV1[i][0]);
              if (dataFromCSV1[i][1] == 1)
                positiveNews1.push(dataFromCSV1[i][0]);
            }
            var num1, num2, num3;
            var largest1 = "";
            num1 = positiveNews1.length;
            num2 = negtiveNews1.length;
            num3 = neutralNews1.length;

            if (num1 > num2 && num1 > num3) {
              largest1 = "fas fa-arrow-up";
            } else if (num2 > num1 && num2 > num3) {
              largest1 = "fas fa-arrow-down";
            } else if (num3 > num1 && num3 > num1) {
              largest1 = "fas fa-arrow-right";
            }
            console.log(largest1);
            var myTempNode1 = {};
            var sentimentScores1 = [
              positiveNews1.length,
              negtiveNews1.length,
              neutralNews1.length
            ];
            if (positiveNews1.length >= 2) {
              var positiveNewsTemp1 = [];
              positiveNewsTemp1.push(positiveNews1[0]);
              positiveNewsTemp1.push(positiveNews1[1]);
              positiveNews1 = positiveNewsTemp1;
            }
            if (negtiveNews1.length >= 2) {
              var negtiveNewsTemp1 = [];
              negtiveNewsTemp1.push(negtiveNews1[0]);
              negtiveNewsTemp1.push(negtiveNews1[1]);
              negtiveNews1 = negtiveNewsTemp1;
            }
            if (neutralNews1.length >= 2) {
              var neutralNewsTemp1 = [];
              neutralNewsTemp1.push(neutralNews1[0]);
              neutralNewsTemp1.push(neutralNews1[1]);
              neutralNews1 = neutralNewsTemp1;
            }

            myTempNode1.name = selectedSymbolsChecked + " symbols";
            myTempNode1.data = sentimentScores1;
            myTempNode1.positiveNews = positiveNews1;
            myTempNode1.negativeNews = negtiveNews1;
            myTempNode1.neutralNews = neutralNews1;
            myTempNode1.largest = largest1;
            dataToBeSent.push(myTempNode1);
            //console.log("dataToBeSent");
            //console.log(myTempNode1);
            //jsonfile.writeFileSync(sectorNewsWithSentiment, dataToBeSent);
            res.send(dataToBeSent);
          });
        });
      } else {
        //jsonfile.writeFileSync(sectorNewsWithSentiment, dataToBeSent);
        res.send(dataToBeSent);
      }
    });
  });
});

app.post("/deleteSector", (req, res) => {
  var sectorSelected = req.body.sectorSelected;
  sectorTreeDataCollection = jsonfile.readFileSync(sectorTree);
  delete sectorTreeDataCollection[sectorSelected];
  console.log(sectorTreeDataCollection);
  jsonfile.writeFileSync(sectorTree, sectorTreeDataCollection);
  res.send(sectorSelected + " deleted successfully");
});

String.prototype.replaceAll = function(find, replace) {
  var str = this;
  return str.replace(
    new RegExp(find.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"), "g"),
    replace
  );
};
