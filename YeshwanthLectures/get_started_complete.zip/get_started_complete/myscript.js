document.addEventListener('click', function(){
	console.log(document.URL);
})