package pdfbox;

import java.io.*;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

public class FinalAnnotation {
    
    static String[] texts;

    public static void main (String[] args) throws Exception {
    	String fileName = args[0];
    	
    	texts = args[1].split(",");
    	
    	File file = new File(fileName);
        PDDocument document = PDDocument.load(file);
    	
        String outputFileName = "SimpleAnnotation1.pdf";
     
        PDPage page = new PDPage(PDRectangle.A4);
            
        document.addPage(page);       

        PDFTextStripper stripper = new MyAnnotator();
        stripper.setSortByPosition(true);
        stripper.setStartPage(0);
        stripper.setEndPage(document.getNumberOfPages());
        Writer dummy = new OutputStreamWriter(new ByteArrayOutputStream());
        stripper.writeText(document, dummy);

        // Save the results and ensure that the document is properly closed
        document.save(outputFileName);
        document.close();
    }

    private static class MyAnnotator extends PDFTextStripper {

        public MyAnnotator() throws IOException {
            super();
        }

        @Override
        protected void writeString (String string, List<TextPosition> textPositions) throws IOException {
            float posXInit = 0, posXEnd = 0, posYInit = 0, posYEnd = 0, height = 0;
            
            for (String anno : texts) {
                if (string.contains(anno)) {
                	posXInit = textPositions.get(0).getXDirAdj();
                    posXEnd  = textPositions.get(textPositions.size() - 1).getXDirAdj() + textPositions.get(textPositions.size() - 1).getWidth();
                    posYInit = textPositions.get(0).getPageHeight() - textPositions.get(0).getYDirAdj();
                    posYEnd  = textPositions.get(0).getPageHeight() - textPositions.get(textPositions.size() - 1).getYDirAdj();
                    height   = textPositions.get(0).getHeightDir();

                    List<PDAnnotation> annotationsInPage = document.getPage(this.getCurrentPageNo() - 1).getAnnotations();
                    PDAnnotationTextMarkup markup = null;
                    // choose any color you want, they can be different for each annotation
                    PDColor color = new PDColor(new float[]{ 1, 1 / 255F, 1 }, PDDeviceRGB.INSTANCE);
                    
                    markup = new PDAnnotationTextMarkup(PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT);                        
                    
                    PDRectangle position = new PDRectangle();
                    position.setLowerLeftX(posXInit);
                    position.setLowerLeftY(posYEnd);
                    position.setUpperRightX(posXEnd);
                    position.setUpperRightY(posYEnd + height);
                    markup.setRectangle(position);

                    float quadPoints[] = {posXInit, posYEnd + height + 2, posXEnd, posYEnd + height + 2, posXInit, posYInit - 2, posXEnd, posYEnd - 2};
                    markup.setQuadPoints(quadPoints);

                    markup.setColor(color);
                    annotationsInPage.add(markup);
                }
            }
        }
    }
}
