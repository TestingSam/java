package pdfbox;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

public class FinalNewAnnotation {
    
    static String[] texts;
    static PDFTextStripper stripper;
    
    public static void main (String[] args) throws Exception {
    	String fileName = args[0];
    	
    	texts = args[1].split(",");
    	
    	File file = new File(fileName);
        PDDocument document = PDDocument.load(file);
    	
        String outputFileName = "SimpleAnnotation1.pdf";
     
        PDPage page = new PDPage(PDRectangle.A4);
            
        document.addPage(page);   
        
        for(String txt : texts)
        {
        	printSubwords(document, txt);
        }

      
        Writer dummy = new OutputStreamWriter(new ByteArrayOutputStream());
        stripper.writeText(document, dummy);

        // Save the results and ensure that the document is properly closed
        document.save(outputFileName);
        document.close();
    }
    
    static void printSubwords(PDDocument document, String searchTerm) throws IOException
    {
        System.out.printf("* Looking for '%s'\n", searchTerm);
        for (int page = 1; page <= document.getNumberOfPages(); page++)
        {
            List<TextPositionSequence> hits = findSubwords(document, page, searchTerm);
            for (TextPositionSequence hit : hits)
            {
                TextPosition lastPosition = hit.textPositionAt(hit.length() - 1);
                
                float posXInit = 0, posXEnd = 0, posYInit = 0, posYEnd = 0, height = 0;                                
                     
                    	posXInit = hit.getX();
                        posXEnd  = lastPosition.getXDirAdj();
                        posYInit = hit.getY();
                        posYEnd  = lastPosition.getYDirAdj();
                        height   = hit.getHeight();

                        List<PDAnnotation> annotationsInPage = document.getPage(page).getAnnotations();
                        PDAnnotationTextMarkup markup = null;
                        // choose any color you want, they can be different for each annotation
                        PDColor color = new PDColor(new float[]{ 1, 1 / 255F, 1 }, PDDeviceRGB.INSTANCE);
                        
                        markup = new PDAnnotationTextMarkup(PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT);                        
                        
                        PDRectangle position = new PDRectangle();
                        position.setLowerLeftX(posXInit);
                        position.setLowerLeftY(posYEnd);
                        position.setUpperRightX(posXEnd);
                        position.setUpperRightY(posYEnd + height);
                        markup.setRectangle(position);

                        float quadPoints[] = {posXInit, posYEnd + height + 2, posXEnd, posYEnd + height + 2, posXInit, posYInit - 2, posXEnd, posYEnd - 2};
                        markup.setQuadPoints(quadPoints);

                        markup.setColor(color);
                        annotationsInPage.add(markup);      
        
    }
    }
    }
    
    static List<TextPositionSequence> findSubwords(PDDocument document, int page, String searchTerm) throws IOException
    {
        final List<TextPositionSequence> hits = new ArrayList<TextPositionSequence>();
        stripper = new PDFTextStripper()
        {
            @Override
            protected void writeString(String text, List<TextPosition> textPositions) throws IOException
            {
                TextPositionSequence word = new TextPositionSequence(textPositions);
                String string = word.toString();

                int fromIndex = 0;
                int index;
                while ((index = string.indexOf(searchTerm, fromIndex)) > -1)
                {
                    hits.add(word.subSequence(index, index + searchTerm.length()));
                    fromIndex = index + 1;
                }
                super.writeString(text, textPositions);
            }
        };

        stripper.setSortByPosition(true);
        stripper.setStartPage(page);
        stripper.setEndPage(page);
        stripper.getText(document);
        return hits;
    }
}    

class TextPositionSequence implements CharSequence
{
    public TextPositionSequence(List<TextPosition> textPositions)
    {
        this(textPositions, 0, textPositions.size());
    }

    public TextPositionSequence(List<TextPosition> textPositions, int start, int end)
    {
        this.textPositions = textPositions;
        this.start = start;
        this.end = end;
    }

    @Override
    public int length()
    {
        return end - start;
    }

    @Override
    public char charAt(int index)
    {
        TextPosition textPosition = textPositionAt(index);
        String text = textPosition.getUnicode();
        return text.charAt(0);
    }

    @Override
    public TextPositionSequence subSequence(int start, int end)
    {
        return new TextPositionSequence(textPositions, this.start + start, this.start + end);
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder(length());
        for (int i = 0; i < length(); i++)
        {
            builder.append(charAt(i));
        }
        return builder.toString();
    }

    public TextPosition textPositionAt(int index)
    {
        return textPositions.get(start + index);
    }

    public float getX()
    {
        return textPositions.get(start).getXDirAdj();
    }

    public float getY()
    {
        return textPositions.get(start).getYDirAdj();
    }

    public float getWidth()
    {
        TextPosition first = textPositions.get(start);
        TextPosition last = textPositions.get(end);
        return last.getWidthDirAdj() + last.getXDirAdj() - first.getXDirAdj();
    }
    
    public float getHeight()
    {
    	return textPositions.get(start).getHeightDir();
    }

    final List<TextPosition> textPositions;
    final int start, end;
}


   