package pdfbox;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;


public class pdfboxread {
	public static void main(String[] args) 
	{
        PDFManager pdfManager = new PDFManager();
        String filePath="C:\\Users\\Simbu\\Downloads\\Personal-Statement-for-Scholarship\\Personal Statement for Scholarship.pdf";
        pdfManager.setFilePath(filePath);
        try {
            //String text = pdfManager.toText();
            //System.out.println(text);
            
            PDDocument document = PDDocument.load(new File(filePath));
            
            PDFTextStripper tStripper = new PDFTextStripper();
            String pdfFileInText = tStripper.getText(document);
            String lines[] = pdfFileInText.split("\\r?\\n");
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
	}
}
